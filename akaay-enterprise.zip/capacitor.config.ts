import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.akaay.enterprise',
  appName: 'Akaay Enterprise',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
