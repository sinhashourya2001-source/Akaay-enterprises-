import React, { useState, useEffect } from 'react';
import { CheckCircle2, X, Crown } from 'lucide-react';
import { db, auth, isFirebaseEnabled, collection, doc, setDoc, getDocs, onSnapshot, query, orderBy, getDoc, deleteDoc, signInWithPopup, GoogleAuthProvider } from './firebase';

import { Product, Order, User, INITIAL_PRODUCTS } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import ProductGrid from './components/ProductGrid';
import CartDrawer from './components/CartDrawer';
import SearchOverlay from './components/SearchOverlay';
import AdminPanel from './components/AdminPanel';
import MyOrders from './components/MyOrders';
import Checkout from './components/Checkout';
import { ProductDetails, AuthView, AccountView, SuccessView } from './components/Views';
import { PrivacyPolicy, TermsOfService, ContactView } from './components/StaticPages';
import { CancelOrderModal, ReturnOrderModal, ReviewModal, DeleteAccountModal } from './components/Modals';

// LocalStorage Helpers
const loadData = (key: string, defaultData: any) => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : defaultData;
};
const saveData = (key: string, data: any) => {
  localStorage.setItem(key, JSON.stringify(data));
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

export default function App() {
  // --- APP STATE ---
  const [currentView, setCurrentView] = useState('HOME'); 
  const [selectedProductId, setSelectedProductId] = useState<string | number | null>(null);
  
  // "Tables" (Local State synced with LocalStorage)
  const [productsDb, setProductsDb] = useState<Product[]>(() => loadData('akaay_products_v3', INITIAL_PRODUCTS));
  const [usersDb, setUsersDb] = useState<User[]>(() => loadData('akaay_users_v3', [])); 
  const [ordersDb, setOrdersDb] = useState<Order[]>(() => loadData('akaay_orders_v3', [])); 
  const [manualRevenues, setManualRevenues] = useState<any[]>(() => loadData('akaay_revenues_v3', []));
  const [notesDb, setNotesDb] = useState<any[]>(() => loadData('akaay_notes_v3', []));
  const [globalSettings, setGlobalSettings] = useState<any>(() => loadData('akaay_settings_v3', { adminPassword: 'akaaypassword', bannerImage: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=1600&q=80", topBannerText: "Bulk Discounts Available - Minimum Order ₹5,000", privacyPolicy: "", termsOfService: "" }));
  
  // Session State
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadData('akaay_currentUser_v3', null));
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [cart, setCart] = useState<(Product & { quantity: number })[]>(() => loadData('akaay_cart_v3', []));
  
  // UI State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [toast, setToast] = useState<string | null>(null);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  
  // Category & Filter State
  const [activeCategory, setActiveCategory] = useState('All');
  
  // Cancellation State
  const [cancellingOrder, setCancellingOrder] = useState<Order | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  // Return & Review State
  const [returningOrder, setReturningOrder] = useState<Order | null>(null);
  const [returnReason, setReturnReason] = useState('');
  const [reviewingItem, setReviewingItem] = useState<any>(null);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '', image: '' });

  // Account Management State
  const [accountForm, setAccountForm] = useState({ name: '', phone: '', address: '', city: '', pincode: '' });
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [deleteAccountReason, setDeleteAccountReason] = useState('');
  
  // Admin Panel State
  const [adminTab, setAdminTab] = useState('DASHBOARD'); 
  const [isAdminSidebarOpen, setIsAdminSidebarOpen] = useState(true);
  const [revenueSearchQuery, setRevenueSearchQuery] = useState('');
  const [revenueForm, setRevenueForm] = useState({ month: 'January', year: new Date().getFullYear().toString(), amount: '' });
  const [manualRevenueSearchQuery, setManualRevenueSearchQuery] = useState('');
  
  // Price Management State
  const [editingPriceItem, setEditingPriceItem] = useState<Product | null>(null);
  const [priceForm, setPriceForm] = useState({ permanentPrice: '', hasSale: false, salePrice: '', saleEndDate: '' });

  // Forms State
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [adminLoginForm, setAdminLoginForm] = useState({ id: '', password: '' });
  
  const [adminSettingsForm, setAdminSettingsForm] = useState({
    currentPassword: '', newPassword: '', confirmPassword: '', rzpKeyId: '', rzpKeySecret: ''
  });
  const [newProductForm, setNewProductForm] = useState({ name: '', price: '', category: 'Beverages', stockQuantity: 10, media: [] as any[], description: '' });
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [checkoutData, setCheckoutData] = useState({ address: '', city: '', pincode: '', phone: '', paymentMethod: 'CARD' });
  const [productDisplayLimit, setProductDisplayLimit] = useState(20);

  // ==========================================
  // INITIALIZATION & SYNC
  // ==========================================

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    const handleScroll = () => {
      if (document.documentElement.scrollHeight - (window.innerHeight + window.scrollY) < 800) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          setProductDisplayLimit(prev => prev + 20);
        }, 150);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(timeoutId);
    };
  }, []);

  // Sync Products from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setProductsDb(loadData('akaay_products_v3', INITIAL_PRODUCTS));
      setIsLoadingProducts(false);
      return;
    }
    const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
      const prods: Product[] = [];
      snapshot.forEach(doc => {
        prods.push(doc.data() as Product);
      });
      // Sort newest products first based on Date.now() ID
      prods.sort((a,b) => Number(b.id) - Number(a.id));
      
      if (prods.length === 0) {
        // If empty Firestore, optionally push initial products (first time setup)
        INITIAL_PRODUCTS.forEach(p => {
          setDoc(doc(db, 'products', String(p.id)), p).catch(console.error);
        });
        setProductsDb(INITIAL_PRODUCTS);
      } else {
        setProductsDb(prods);
      }
      setIsLoadingProducts(false);
    }, (error) => {
      console.error("Firestore Products Error:", error);
      if (error.message.includes("Missing or insufficient permissions")) {
        alert("CRITICAL ERROR: Your Firebase Database rules are blocking reads/writes! Please go to your Firebase Console -> Firestore Database -> Rules, and set 'allow read, write: if true;' to make the website fully functional for everyone.");
      }
      setIsLoadingProducts(false);
    });
    return () => unsub();
  }, []);

  // Sync Orders from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setOrdersDb(loadData('akaay_orders_v3', []));
      return;
    }
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      const orders: Order[] = [];
      snapshot.forEach(doc => {
        orders.push(doc.data() as Order);
      });
      setOrdersDb(orders);
    }, (error) => {
      console.error("Firestore Orders Error:", error);
      if (error.message.includes("permission")) {
        console.error("Firebase permissions blocking Orders sync.");
      }
    });
    return () => unsub();
  }, []);

  // Sync Users from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setUsersDb(loadData('akaay_users_v3', []));
      return;
    }
    const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
      const users: User[] = [];
      snapshot.forEach(doc => {
        users.push(doc.data() as User);
      });
      setUsersDb(users);
    });
    return () => unsub();
  }, []);

  // Sync Revenues from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setManualRevenues(loadData('akaay_revenues_v3', []));
      return;
    }
    const unsub = onSnapshot(collection(db, 'revenues'), (snapshot) => {
      const revs: any[] = [];
      snapshot.forEach(doc => revs.push(doc.data()));
      revs.sort((a,b) => Number(b.id) - Number(a.id));
      setManualRevenues(revs);
    });
    return () => unsub();
  }, []);

  // Sync Notes from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setNotesDb(loadData('akaay_notes_v3', []));
      return;
    }
    const unsub = onSnapshot(collection(db, 'notes'), (snapshot) => {
      const notes: any[] = [];
      snapshot.forEach(doc => notes.push(doc.data()));
      notes.sort((a,b) => Number(b.id) - Number(a.id));
      setNotesDb(notes);
    });
    return () => unsub();
  }, []);

  // Sync Global Settings from Firestore
  useEffect(() => {
    if (!isFirebaseEnabled || !db) {
      setGlobalSettings(loadData('akaay_settings_v3', { adminPassword: 'akaaypassword', bannerImage: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=1600&q=80", topBannerText: "Bulk Discounts Available - Minimum Order ₹5,000", privacyPolicy: "", termsOfService: "" }));
      return;
    }
    const unsub = onSnapshot(doc(db, 'settings', 'global'), (docSnap) => {
      if (docSnap.exists()) {
        setGlobalSettings(docSnap.data());
      } else {
        const local = loadData('akaay_settings_v3', { adminPassword: 'akaaypassword', bannerImage: "https://images.unsplash.com/photo-1587293852726-70cdb56c2866?auto=format&fit=crop&w=1600&q=80", topBannerText: "Bulk Discounts Available - Minimum Order ₹5,000", privacyPolicy: "", termsOfService: "" });
        setGlobalSettings(local);
        setDoc(doc(db, 'settings', 'global'), local).catch(console.error);
      }
    });
    return () => unsub();
  }, []);

  // Sync Current User specifically if logged in
  useEffect(() => {
    if (!isFirebaseEnabled || !db || !currentUser?.id) return;
    const unsub = onSnapshot(doc(db, 'users', currentUser.id), (docSnap) => {
      if (docSnap.exists()) {
        const userData = docSnap.data() as User;
        // Only update if something actually changed to avoid loops
        if (JSON.stringify(userData) !== JSON.stringify(currentUser)) {
          setCurrentUser(userData);
        }
      }
    });
    return () => unsub();
  }, [currentUser?.id]);

  // Pre-loaded synchronously during useState creation, so we don't need a redundant async mounting fetch.

  useEffect(() => { saveData('akaay_products_v3', productsDb); }, [productsDb]);
  useEffect(() => { saveData('akaay_users_v3', usersDb); }, [usersDb]);
  useEffect(() => { saveData('akaay_orders_v3', ordersDb); }, [ordersDb]);
  useEffect(() => { saveData('akaay_revenues_v3', manualRevenues); }, [manualRevenues]);
  useEffect(() => { saveData('akaay_notes_v3', notesDb); }, [notesDb]);
  useEffect(() => { saveData('akaay_settings_v3', globalSettings); }, [globalSettings]);
  useEffect(() => { saveData('akaay_currentUser_v3', currentUser); }, [currentUser]);
  useEffect(() => { saveData('akaay_cart_v3', cart); }, [cart]);

  // Sync account form with current user data when opening account page
  useEffect(() => {
    if (currentView === 'ACCOUNT' && currentUser) {
      setAccountForm({
        name: currentUser.name || '', phone: currentUser.phone || '',
        address: currentUser.address || '', city: currentUser.city || '',
        pincode: currentUser.pincode || ''
      });
    }
  }, [currentView, currentUser]);

  // Automated Discount Expiration Checker
  useEffect(() => {
    if (!isAdminLoggedIn) return;
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      let updated = false;
      const newProducts = productsDb.map(p => {
        if (p.saleEndDate && now >= new Date(p.saleEndDate).getTime()) {
          updated = true;
          return { ...p, price: p.originalPrice || p.price, originalPrice: null, saleEndDate: null };
        }
        return p;
      });
      if (updated) setProductsDb(newProducts);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [productsDb, isAdminLoggedIn]);

  // Sync cart prices to DB changes automatically
  useEffect(() => {
    setCart(prevCart => prevCart.map(cItem => {
      const dbProduct = productsDb.find(p => p.id === cItem.id);
      if (dbProduct && dbProduct.price !== cItem.price) {
        return { ...cItem, price: dbProduct.price };
      }
      return cItem;
    }));
  }, [productsDb]);

  // --- HELPER FUNCTIONS ---
  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 3000);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  const navigateTo = (view: string, productId: string | number | null = null) => {
    setCurrentView(view);
    if (productId) {
      setSelectedProductId(productId);
      setActiveMediaIdx(0); 
    }
    window.scrollTo(0, 0);
    setIsMobileMenuOpen(false);
    setIsCartDrawerOpen(false);
    setIsSearchOpen(false);
    setSearchQuery('');
  };

  const handleCategoryClick = (category: string) => {
    setActiveCategory(category);
    setProductDisplayLimit(20);
    if (currentView !== 'HOME') setCurrentView('HOME');
    setIsMobileMenuOpen(false);
    
    setTimeout(() => {
      const grid = document.getElementById('products-grid');
      if (grid) {
        const y = grid.getBoundingClientRect().top + window.scrollY - 80;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
    }, 100);
  };

  // --- CART LOGIC ---
  const addToCart = (product: Product) => {
    if (!product.inStock || product.stockQuantity <= 0) {
      showToast("Sorry, this piece is out of stock.");
      return;
    }
    const existing = cart.find(item => item.id === product.id);
    if (existing && existing.quantity >= product.stockQuantity) {
      showToast(`Only ${product.stockQuantity} available in stock.`);
      return;
    }

    setCart(prev => {
      const currentItem = prev.find(item => item.id === product.id);
      if (currentItem) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
    
    showToast(`${product.name} added to collection`);
    setIsCartDrawerOpen(true);
  };

  const handleBuyNow = (product: Product) => {
    if (!product.inStock || product.stockQuantity <= 0) return showToast("Sorry, this piece is out of stock.");
    const existing = cart.find(item => item.id === product.id);
    if (!existing) setCart(prev => [...prev, { ...product, quantity: 1 }]);
    navigateTo('CHECKOUT');
  };

  const updateQuantity = (id: string | number, delta: number) => {
    const product = productsDb.find(p => p.id === id);
    const cartItem = cart.find(c => c.id === id);
    if (!product || !cartItem) return;
    const newQty = cartItem.quantity + delta;
    
    if (newQty > product.stockQuantity) return showToast(`Only ${product.stockQuantity} available in stock.`);
    if (newQty <= 0) return removeFromCart(id);
    
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: newQty } : item));
  };

  const removeFromCart = (id: string | number) => setCart(prev => prev.filter(item => item.id !== id));

  const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);
  const shippingFee = cartTotal > 0 && cartTotal < 1000 ? 50 : 0;
  const orderTotal = cartTotal + shippingFee;

  useEffect(() => {
    if (orderTotal > 2000 && checkoutData.paymentMethod === 'COD') setCheckoutData(prev => ({ ...prev, paymentMethod: 'CARD' }));
  }, [orderTotal, checkoutData.paymentMethod]);

  // --- AUTH LOGIC ---
  const handleGoogleLogin = async () => {
    if (!auth || !isFirebaseEnabled) {
      showToast("Firebase is not enabled. Please check configuration.");
      return;
    }
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      const newUser: User = {
        id: user.uid,
        name: user.displayName || 'Google User',
        email: user.email || '',
        password: '', // No password for Google users
        phone: '', address: '', city: '', pincode: ''
      };
      
      setCurrentUser(newUser);
      
      // If admin email, auto-promote to admin panel view if they want
      if (user.email === "archanakumari0304@gmail.com") {
        setIsAdminLoggedIn(true);
        showToast("Admin access granted.");
      } else {
        showToast(`Welcome, ${user.displayName || 'Wholesaler'}!`);
      }
      
      // Save user to Firestore if doesn't exist
      if (isFirebaseEnabled && db) {
        setDoc(doc(db, 'users', user.uid), newUser, { merge: true }).catch(console.error);
      }
      
      navigateTo('HOME');
    } catch (error) {
      console.error("Google Login Error:", error);
      showToast("Authentication failed.");
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (usersDb.find(u => u.email === authForm.email)) return showToast("Email already exists!");
    
    const newUser: User = { 
      id: Date.now().toString(), 
      name: authForm.name, 
      email: authForm.email, 
      password: authForm.password,
      phone: '', address: '', city: '', pincode: ''
    };
    
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'users', newUser.id), newUser).catch(console.error);
    }
    setUsersDb([...usersDb, newUser]);
    setCurrentUser(newUser);
    setAuthForm({ name: '', email: '', password: '' });
    showToast("Welcome back, Partner!");
    navigateTo('HOME');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = usersDb.find(u => u.email === authForm.email && u.password === authForm.password);
    if (user) {
      setCurrentUser(user);
      setAuthForm({ name: '', email: '', password: '' });
      showToast(`Welcome back, ${user.name}!`);
      navigateTo('HOME');
    } else {
      showToast("Invalid email or password.");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAdminLoggedIn(false);
    showToast("Logged out successfully");
    navigateTo('HOME');
  };

  // --- ACCOUNT MANAGEMENT LOGIC ---
  const handleUpdateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...accountForm };
    setUsersDb(usersDb.map(u => u.id === currentUser.id ? updatedUser : u));
    setCurrentUser(updatedUser);
    showToast("Account details updated securely.");
  };

  const handleConfirmDeleteAccount = () => {
    if (!deleteAccountReason.trim()) return showToast("Please provide a reason to proceed with deletion.");
    if (!currentUser) return;
    setUsersDb(usersDb.filter(u => u.id !== currentUser.id));
    setCurrentUser(null);
    setCart([]);
    setShowDeleteAccountModal(false);
    setDeleteAccountReason('');
    showToast("Your account has been permanently deleted.");
    navigateTo('HOME');
  };

  // --- ADMIN LOGIC ---
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLoginForm.id === 'akaayadmin' && adminLoginForm.password === globalSettings.adminPassword) {
      setIsAdminLoggedIn(true);
      setAdminLoginForm({ id: '', password: '' });
      showToast("Admin access granted.");
      navigateTo('ADMIN_PANEL');
    } else {
      showToast("Invalid Admin Credentials.");
    }
  };

  const handleAddManualRevenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!revenueForm.amount || isNaN(Number(revenueForm.amount)) || Number(revenueForm.amount) < 0) return showToast("Please enter a valid revenue amount.");
    
    const newEntry = {
      id: Date.now().toString(),
      month: revenueForm.month,
      year: revenueForm.year,
      amount: Number(revenueForm.amount),
      dateAdded: new Date().toLocaleString()
    };
    
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'revenues', newEntry.id), newEntry).catch(console.error);
    }
    setManualRevenues([newEntry, ...manualRevenues]);
    setRevenueForm({ ...revenueForm, amount: '' });
    showToast("Monthly revenue recorded successfully.");
  };

  const deleteManualRevenue = (id: string) => {
    if (isFirebaseEnabled && db) {
      deleteDoc(doc(db, 'revenues', id)).catch(console.error);
    }
    setManualRevenues(manualRevenues.filter(r => r.id !== id));
    showToast("Revenue record removed.");
  };

  const handleAddNote = (e: React.FormEvent, text: string) => {
    e.preventDefault();
    if (!text.trim()) return showToast("Note cannot be empty.");
    const newNote = {
      id: Date.now().toString(),
      text,
      date: new Date().toLocaleString()
    };
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'notes', newNote.id), newNote).catch(console.error);
    }
    setNotesDb([newNote, ...notesDb]);
    showToast("Note added successfully.");
  };

  const deleteNote = (id: string) => {
    if (isFirebaseEnabled && db) {
      deleteDoc(doc(db, 'notes', id)).catch(console.error);
    }
    setNotesDb(notesDb.filter(n => n.id !== id));
    showToast("Note removed.");
  };

  const handleMediaUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !files.length) return;

    const oversized = Array.from(files).some((f: any) => f.size > 800000);
    if (oversized) return showToast("One or more files are too large (Max 800KB for cloud sync).");
    
    try {
      const newMediaItems = await Promise.all(Array.from(files).map(async (file: File) => {
        const isVideo = file.type.startsWith('video/');
        const base64 = await fileToBase64(file);
        return { id: Date.now() + Math.random(), type: isVideo ? ('video' as const) : ('image' as const), url: base64 };
      }));
      setNewProductForm(prev => ({...prev, media: [...prev.media, ...newMediaItems]}));
    } catch (error) {
      console.error("Upload error:", error);
      showToast("Failed to process image.");
    }
    e.target.value = '';
  };

  const removeMedia = (idToRemove: number) => {
    setNewProductForm(prev => ({ ...prev, media: prev.media.filter(m => m.id !== idToRemove) }));
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (newProductForm.media.length === 0) return showToast("Please upload at least one image or video.");
    
    const firstMedia = newProductForm.media[0];
    const parsedQuantity = Math.max(0, parseInt(newProductForm.stockQuantity.toString()) || 0);

    const newProduct: Product = {
      id: Date.now().toString(),
      name: newProductForm.name,
      price: Number(newProductForm.price),
      category: newProductForm.category,
      image: firstMedia.url, 
      mainMediaType: firstMedia.type,
      media: newProductForm.media,
      description: newProductForm.description,
      isNew: true,
      stockQuantity: parsedQuantity,
      inStock: parsedQuantity > 0,
      rating: 0,
      reviews: []
    };

    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'products', String(newProduct.id)), newProduct).catch(console.error);
    }
    setProductsDb([newProduct, ...productsDb]);
    showToast("Product added successfully!");
    setNewProductForm({ name: '', price: '', category: 'Beverages', stockQuantity: 10, media: [], description: '' });
    setAdminTab('MANAGE_PRODUCTS');
  };

  const handleUpdateStock = (id: string | number, newQuantity: string) => {
    const parsedQty = Math.max(0, parseInt(newQuantity) || 0);
    const product = productsDb.find(p => p.id === id);
    if (product) {
      const updated = { ...product, stockQuantity: parsedQty, inStock: parsedQty > 0 };
      if (isFirebaseEnabled && db) {
        setDoc(doc(db, 'products', String(id)), updated).catch(console.error);
      }
    }
    setProductsDb(productsDb.map(p => p.id === id ? { ...p, stockQuantity: parsedQty, inStock: parsedQty > 0 } : p));
  };

  const deleteProduct = (id: string | number) => {
    if (isFirebaseEnabled && db) {
      deleteDoc(doc(db, 'products', String(id))).catch(console.error);
    }
    setProductsDb(productsDb.filter(p => p.id !== id));
    showToast("Product removed permanently.");
  };

  const updateProductImage = async (id: string | number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 800000) return showToast("File is too large (Max 800KB for cloud sync).");
      const isVideo = file.type.startsWith('video/');
      try {
        const fileUrl = await fileToBase64(file);
        const updatedProds = productsDb.map(p => p.id === id ? { ...p, image: fileUrl, mainMediaType: isVideo ? ('video' as const) : ('image' as const) } : p);
        setProductsDb(updatedProds);
        
        if (isFirebaseEnabled && db) {
          const updatedProduct = updatedProds.find(p => p.id === id);
          if (updatedProduct) {
            import('./firebase').then(({ setDoc, doc }) => {
              setDoc(doc(db, 'products', String(id)), updatedProduct).catch(console.error);
            });
          }
        }
        showToast("Product media updated and synced.");
      } catch (error) {
        showToast("Failed to update media.");
      }
    }
  };

  const handleOpenPriceEdit = (product: Product) => {
    setEditingPriceItem(product);
    setPriceForm({
      permanentPrice: (product.originalPrice || product.price).toString(),
      hasSale: !!product.saleEndDate,
      salePrice: product.originalPrice ? product.price.toString() : '',
      saleEndDate: product.saleEndDate || ''
    });
  };

  const handleSavePriceEdit = () => {
    if (!editingPriceItem) return;
    const permPrice = Number(priceForm.permanentPrice);
    if (!permPrice || permPrice <= 0) return showToast("Please enter a valid permanent price.");

    let updateData: any = {};
    if (priceForm.hasSale) {
      const sPrice = Number(priceForm.salePrice);
      if (!sPrice || sPrice <= 0) return showToast("Please enter a valid discount price.");
      if (sPrice >= permPrice) return showToast("Discount price must be lower than the permanent price.");
      if (!priceForm.saleEndDate || new Date(priceForm.saleEndDate).getTime() <= new Date().getTime()) return showToast("Sale end date must be valid and in the future.");
      
      updateData = { originalPrice: permPrice, price: sPrice, saleEndDate: priceForm.saleEndDate };
    } else {
      updateData = { price: permPrice, originalPrice: null, saleEndDate: null };
    }

    const updated = { ...editingPriceItem, ...updateData };
    setProductsDb(productsDb.map(p => p.id === editingPriceItem.id ? updated : p));
    
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'products', String(editingPriceItem.id)), updated).catch(console.error);
    }
    
    showToast("Pricing configuration saved successfully.");
    setEditingPriceItem(null);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminSettingsForm.currentPassword !== globalSettings.adminPassword) return showToast("Incorrect current password.");
    if (adminSettingsForm.newPassword !== adminSettingsForm.confirmPassword) return showToast("Passwords do not match.");
    if (adminSettingsForm.newPassword.length < 6) return showToast("Password must be at least 6 characters.");
    
    const updated = { ...globalSettings, adminPassword: adminSettingsForm.newPassword };
    setGlobalSettings(updated);
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'settings', 'global'), updated).catch(console.error);
    }
    setAdminSettingsForm(prev => ({...prev, currentPassword: '', newPassword: '', confirmPassword: ''}));
    showToast("Admin password updated successfully!");
  };

  const handleRazorpayUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminSettingsForm.rzpKeyId || !adminSettingsForm.rzpKeySecret) return showToast("Please provide both Key ID and Secret.");
    const updated = { ...globalSettings, rzpKeyId: adminSettingsForm.rzpKeyId, rzpKeySecret: adminSettingsForm.rzpKeySecret };
    setGlobalSettings(updated);
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'settings', 'global'), updated).catch(console.error);
    }
    showToast("Razorpay API keys securely linked!");
  };

  const handleBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 800000) return showToast("Banner image is too large (Max 800KB for cloud sync).");
      try {
        const fileUrl = await fileToBase64(file);
        const updated = { ...globalSettings, bannerImage: fileUrl };
        if (isFirebaseEnabled && db) {
          setDoc(doc(db, 'settings', 'global'), updated).catch(console.error);
        }
        setGlobalSettings(updated);
        showToast("Store banner updated successfully.");
      } catch (error) {
        showToast("Failed to process banner.");
      }
    }
  };

  const handleRemoveBanner = () => {
    const updated = { ...globalSettings, bannerImage: null };
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'settings', 'global'), updated).catch(console.error);
    }
    setGlobalSettings(updated);
    showToast("Store banner removed.");
  };

  const handleUpdateLegalAndBanner = (e: React.FormEvent, newSettings: any) => {
    e.preventDefault();
    const updated = { ...globalSettings, ...newSettings };
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'settings', 'global'), updated).catch(console.error);
    }
    setGlobalSettings(updated);
    showToast("Legal & Banner settings updated successfully.");
  };

  // --- CHECKOUT & PAYMENT LOGIC ---
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();

    const invalidItems = cart.filter(cartItem => {
      const dbProduct = productsDb.find(p => p.id === cartItem.id);
      return !dbProduct || !dbProduct.inStock || cartItem.quantity > dbProduct.stockQuantity;
    });

    if (invalidItems.length > 0) return showToast(`Checkout blocked: ${invalidItems[0].name} has insufficient stock.`);
    if (!checkoutData.address || !checkoutData.phone) return showToast("Please fill all shipping details.");
    
    completeOrder();
  };

  const completeOrder = (paymentId: string | null = null) => {
    const now = new Date();
    const newOrder: Order = {
      orderId: 'AKAAY-' + Math.floor(100000 + Math.random() * 900000),
      date: now.toLocaleString(),
      createdAt: now.toISOString(),
      customer: currentUser!,
      shipping: checkoutData,
      items: [...cart],
      subtotal: cartTotal,
      shippingFee: shippingFee,
      total: orderTotal,
      paymentMethod: checkoutData.paymentMethod,
      transactionId: paymentId,
      status: 'Pending'
    };
    
    // Process Stock Deductions
    const updatedProducts = productsDb.map(p => {
      const cItem = cart.find(c => c.id === p.id);
      if (cItem) {
        const newQty = Math.max(0, p.stockQuantity - cItem.quantity);
        return { ...p, stockQuantity: newQty, inStock: newQty > 0 };
      }
      return p;
    });
    setProductsDb(updatedProducts);

    // Save Order to Firestore
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'orders', newOrder.orderId), newOrder).catch(err => {
        console.error("Order Save Error:", err);
        showToast("Order saved locally, but cloud sync failed.");
      });

      // Update Product Stock in Firestore
      updatedProducts.forEach(p => {
        const cItem = cart.find(c => c.id === p.id);
        if (cItem) {
          setDoc(doc(db, 'products', String(p.id)), p).catch(console.error);
        }
      });
    }

    setOrdersDb(prev => [newOrder, ...prev]);
    
    setCart([]);
    navigateTo('SUCCESS');
    showToast("Order placed successfully!");
  };

  // --- ORDER CANCELLATION & RETURN ---
  const submitCancellation = () => {
    if (!cancelReason.trim()) return showToast("Please provide a reason for cancellation.");
    if (!cancellingOrder) return;
    const updated = { ...cancellingOrder, status: 'Cancelled', cancelReason };
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'orders', cancellingOrder.orderId), updated).catch(err => {
        console.error("Cancellation Sync Error:", err);
        showToast("Cloud sync failed, change might not persist.");
      });
    }
    setOrdersDb(ordersDb.map(o => o.orderId === cancellingOrder.orderId ? updated : o));
    setCancellingOrder(null);
    setCancelReason('');
    showToast("Order has been cancelled.");
  };

  const handleOrderStatusChange = (orderId: string, newStatus: string) => {
    const order = ordersDb.find(o => o.orderId === orderId);
    if (order) {
      const updated = { ...order, status: newStatus, deliveryDate: newStatus === 'Delivered' ? new Date().getTime() : order.deliveryDate };
      if (isFirebaseEnabled && db) {
        setDoc(doc(db, 'orders', orderId), updated).catch(console.error);
      }
    }
    setOrdersDb(ordersDb.map(o => {
      if (o.orderId === orderId) {
        return { ...o, status: newStatus, deliveryDate: newStatus === 'Delivered' ? new Date().getTime() : o.deliveryDate };
      }
      return o;
    }));
    showToast(`Order marked as: ${newStatus}`);
  };

  const submitReturn = () => {
    if (!returnReason.trim()) return showToast("Please provide a reason for the return.");
    if (!returningOrder) return;
    const updated = { ...returningOrder, status: 'Return Requested', returnReason };
    if (isFirebaseEnabled && db) {
      setDoc(doc(db, 'orders', returningOrder.orderId), updated).catch(console.error);
    }
    setOrdersDb(ordersDb.map(o => o.orderId === returningOrder.orderId ? updated : o));
    setReturningOrder(null);
    setReturnReason('');
    showToast("Return request submitted.");
  };

  const handleReviewImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2000000) return showToast("Image is too large (max 2MB).");
      const reader = new FileReader();
      reader.onloadend = () => setReviewForm({ ...reviewForm, image: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const submitReview = () => {
    if (!reviewForm.comment.trim()) return showToast("Please write a quick comment for your review.");
    if (!reviewingItem || !currentUser) return;
    
    const newReview = { id: Date.now(), user: currentUser.name, rating: reviewForm.rating, comment: reviewForm.comment, image: reviewForm.image };
    
    const updatedProducts = productsDb.map(p => {
      if (p.id === reviewingItem.productId) {
        const updated = { ...p, reviews: [newReview, ...(p.reviews || [])] };
        if (isFirebaseEnabled && db) {
          setDoc(doc(db, 'products', String(p.id)), updated).catch(console.error);
        }
        return updated;
      }
      return p;
    });
    setProductsDb(updatedProducts);

    const updatedOrders = ordersDb.map(o => {
      if (o.orderId === reviewingItem.orderId) {
        const updated = { ...o, items: o.items.map(i => i.id === reviewingItem.productId ? { ...i, reviewed: true } : i) };
        if (isFirebaseEnabled && db) {
          setDoc(doc(db, 'orders', o.orderId), updated).catch(console.error);
        }
        return updated;
      }
      return o;
    });
    setOrdersDb(updatedOrders);

    showToast("Thank you for sharing your experience!");
    setReviewingItem(null);
    setReviewForm({ rating: 5, comment: '', image: '' });
  };

  // ==========================================
  // RENDER HELPERS
  // ==========================================

  const renderHome = () => {
    const defaultDisplay = activeCategory === 'All' ? productsDb : productsDb.filter(p => p.category === activeCategory);
    const displayProducts = defaultDisplay.slice(0, productDisplayLimit);
    const sectionTitle = activeCategory === 'All' ? "Curated Collection" : activeCategory;

    return (
      <div className="animate-fade-in">
        <section className="relative h-[80vh] w-full bg-black overflow-hidden">
          {globalSettings.bannerImage && (
            <img src={globalSettings.bannerImage} alt="Wholesale Warehouse" className="absolute inset-0 w-full h-full object-cover object-center opacity-40 mix-blend-luminosity animate-fade-in" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
          <div className="absolute inset-0 flex flex-col items-center justify-end md:justify-center text-center pb-20 md:pb-0 px-4">
            <span className="text-[#C5A059] tracking-[0.3em] text-xs md:text-sm font-bold uppercase mb-4 flex items-center">The Akaay Enterprise Vault</span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white mb-8 max-w-4xl leading-tight uppercase tracking-wider">
              Wholesale <br className="hidden md:block" />
              <span className="text-gray-300 italic font-light lowercase">supplies</span>
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto mb-10 text-lg font-light">Source high-quality wholesale products directly from our warehouse.</p>
            <button onClick={() => window.scrollTo({top: 800, behavior: 'smooth'})} className="bg-[#C5A059] text-white px-8 py-4 tracking-[0.2em] text-sm uppercase hover:bg-white hover:text-black transition-colors duration-300 font-bold">Shop Wholesale</button>
          </div>
        </section>

        <div id="products-grid" className="pt-12 scroll-mt-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 hidden lg:flex justify-center space-x-12 border-b border-gray-200 pb-4 mb-4">
             {['All', 'Beverages', 'Chocolates', 'Snacks'].map(cat => (
               <button key={cat} onClick={() => handleCategoryClick(cat)} className={`text-sm tracking-widest uppercase transition-colors ${activeCategory === cat ? 'text-black font-bold border-b-2 border-[#C5A059] pb-4 -mb-[18px]' : 'text-gray-500 hover:text-black'}`}>
                 {cat === 'All' ? 'All Products' : cat}
               </button>
             ))}
          </div>
          <ProductGrid products={displayProducts} title={sectionTitle} onProductClick={(id) => navigateTo('PRODUCT', id)} onAddToCart={addToCart} isLoading={isLoadingProducts} />
          {!isLoadingProducts && displayProducts.length === 0 && <p className="text-center text-gray-500 mb-20 font-serif text-xl">No products currently available in this category.</p>}
        </div>
      </div>
    );
  };

  const renderEditPriceModal = () => {
    if (!editingPriceItem) return null;

    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
        <div className="bg-white w-full max-w-md border border-gray-200 shadow-2xl p-10">
          <div className="flex items-center justify-between mb-8"><h2 className="text-2xl font-serif uppercase tracking-widest text-black">Update Pricing</h2><button onClick={() => setEditingPriceItem(null)}><X className="text-gray-400 hover:text-black w-6 h-6" /></button></div>
          <p className="text-sm text-[#C5A059] mb-8 font-bold uppercase tracking-wider line-clamp-1">Piece: {editingPriceItem.name}</p>
          <div className="space-y-6 mb-10">
            <div>
              <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2 font-bold">Permanent Price (₹)</label>
              <input type="number" value={priceForm.permanentPrice} onChange={(e) => setPriceForm({...priceForm, permanentPrice: e.target.value})} className="w-full border border-gray-300 p-4 text-sm focus:outline-none focus:border-black bg-gray-50 transition-colors" placeholder="Standard base price" />
            </div>
            <label className="flex items-center space-x-3 cursor-pointer">
              <input type="checkbox" checked={priceForm.hasSale} onChange={(e) => setPriceForm({...priceForm, hasSale: e.target.checked})} className="w-4 h-4 accent-black cursor-pointer" />
              <span className="text-xs font-bold uppercase tracking-widest text-gray-600">Schedule Temporary Discount</span>
            </label>
            {priceForm.hasSale && (
              <div className="p-6 border border-[#C5A059] bg-[#C5A059]/5 space-y-6">
                <div><label className="block text-[10px] tracking-widest uppercase text-[#C5A059] mb-2 font-bold">Discount Price (₹)</label><input type="number" value={priceForm.salePrice} onChange={(e) => setPriceForm({...priceForm, salePrice: e.target.value})} className="w-full border border-[#C5A059] p-3 text-sm focus:outline-none focus:ring-1 focus:ring-[#C5A059] bg-white transition-colors" placeholder="Promotional price" /></div>
                <div><label className="block text-[10px] tracking-widest uppercase text-[#C5A059] mb-2 font-bold">Sale Ends On</label><input type="datetime-local" value={priceForm.saleEndDate} onChange={(e) => setPriceForm({...priceForm, saleEndDate: e.target.value})} className="w-full border border-[#C5A059] p-3 text-sm focus:outline-none focus:ring-1 focus:ring-[#C5A059] bg-white transition-colors cursor-pointer" /><p className="text-[9px] uppercase tracking-widest text-gray-500 mt-2 font-bold">Price automatically reverts after this time.</p></div>
              </div>
            )}
          </div>
          <button onClick={handleSavePriceEdit} className="w-full bg-black text-[#C5A059] py-5 tracking-[0.2em] text-xs uppercase font-bold hover:bg-[#C5A059] hover:text-white transition-colors border border-black">Save Pricing Configuration</button>
        </div>
      </div>
    );
  };

  return (
    <>
      {isLoadingProducts && currentView === 'HOME' && (
        <div className="fixed inset-0 z-[500] bg-white flex flex-col pt-32 pb-16 overflow-hidden">
          {/* Skeleton Header */}
          <div className="fixed top-0 left-0 right-0 h-32 bg-white flex flex-col border-b border-gray-100 px-4 md:px-8 py-4">
            <div className="flex justify-between items-center flex-1">
              <div className="h-4 w-6 bg-gray-200 animate-pulse"></div>
              <div className="h-6 w-32 bg-gray-200 animate-pulse"></div>
              <div className="flex gap-4">
                <div className="h-5 w-5 bg-gray-200 animate-pulse"></div>
                <div className="h-5 w-5 bg-gray-200 animate-pulse"></div>
              </div>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto w-full max-w-7xl mx-auto px-4 w-full">
            {/* Hero Skeleton */}
            <div className="h-[60vh] bg-gray-100 animate-pulse mb-12 w-full flex items-center justify-center flex-col gap-6">
               <div className="h-4 w-48 bg-gray-200"></div>
               <div className="h-16 w-3/4 max-w-2xl bg-gray-200"></div>
               <div className="h-6 w-64 bg-gray-200"></div>
            </div>

            {/* Categories Skeleton */}
            <div className="flex justify-center gap-8 mb-12 hidden lg:flex">
               {[1,2,3,4].map(i => <div key={i} className="h-4 w-24 bg-gray-200 animate-pulse"></div>)}
            </div>
            
            {/* Grid Skeleton */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8 pb-32">
               {[...Array(8)].map((_, i) => (
                <div key={i} className="flex flex-col animate-pulse">
                  <div className="bg-gray-200 aspect-[3/4] mb-4 w-full"></div>
                  <div className="h-3 bg-gray-200 mb-2 w-1/3"></div>
                  <div className="h-4 bg-gray-200 mb-2 w-3/4"></div>
                  <div className="h-4 bg-gray-200 mt-auto w-1/4"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      <div className="min-h-screen bg-white text-black font-sans selection:bg-[#C5A059] selection:text-white flex flex-col">
      {toast && <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-black text-[#C5A059] border border-[#C5A059] px-8 py-4 shadow-2xl z-[300] text-xs uppercase tracking-widest font-bold animate-fade-in-up flex items-center"><CheckCircle2 className="w-4 h-4 mr-3 text-[#C5A059]" /> {toast}</div>}

      {currentView !== 'ADMIN_PANEL' && currentView !== 'ADMIN_LOGIN' && (
        <Header 
          currentUser={currentUser} 
          cartCount={cartCount} 
          onNavigate={navigateTo} 
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)} 
          onOpenCart={() => setIsCartDrawerOpen(true)} 
          onOpenSearch={() => setIsSearchOpen(true)} 
          onCategoryClick={handleCategoryClick} 
          topBannerText={globalSettings.topBannerText}
        />
      )}

      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="relative w-[85%] max-w-sm bg-white h-full shadow-2xl flex flex-col pt-24 px-10 pb-10 overflow-y-auto border-r border-gray-200">
            <button className="absolute top-8 right-8 text-gray-400 hover:text-black" onClick={() => setIsMobileMenuOpen(false)}><X className="w-8 h-8" /></button>
            <nav className="flex flex-col space-y-8 text-base font-serif tracking-widest uppercase font-bold text-gray-500">
              <button onClick={() => { setActiveCategory('All'); navigateTo('HOME'); }} className="text-left border-b border-gray-100 pb-4 hover:text-black">Products</button>
              {currentUser && <button onClick={() => navigateTo('ACCOUNT')} className="text-left border-b border-gray-100 pb-4 text-[#C5A059]">My Account</button>}
              <button onClick={() => navigateTo('MY_ORDERS')} className="text-left border-b border-gray-100 pb-4 hover:text-black">My Orders</button>
              <button onClick={() => handleCategoryClick('Beverages')} className={`text-left border-b border-gray-100 pb-4 transition-colors ${activeCategory === 'Beverages' ? 'text-black' : 'hover:text-black'}`}>Beverages</button>
              <button onClick={() => handleCategoryClick('Chocolates')} className={`text-left border-b border-gray-100 pb-4 transition-colors ${activeCategory === 'Chocolates' ? 'text-black' : 'hover:text-black'}`}>Chocolates</button>
              <button onClick={() => handleCategoryClick('Snacks')} className={`text-left border-b border-gray-100 pb-4 transition-colors ${activeCategory === 'Snacks' ? 'text-black' : 'hover:text-black'}`}>Snacks</button>

              {!currentUser && (
                <><button onClick={() => navigateTo('LOGIN')} className="text-left border-b border-gray-100 pb-4 mt-6 text-xs font-sans hover:text-black">Wholesaler Login</button><button onClick={() => navigateTo('SIGNUP')} className="text-left pb-4 text-xs font-sans hover:text-[#C5A059]">Register</button></>
              )}
            </nav>
          </div>
        </div>
      )}

      {/* Global Skeleton */}
      
      <main className="flex-grow">
        {currentView === 'HOME' && renderHome()}
        {currentView === 'PRODUCT' && selectedProductId && (
          <ProductDetails 
            product={productsDb.find(p => p.id === selectedProductId)!} 
            activeMediaIdx={activeMediaIdx} 
            setActiveMediaIdx={setActiveMediaIdx} 
            onAddToCart={addToCart} 
            onBuyNow={handleBuyNow} 
            onNavigate={navigateTo} 
            formatPrice={formatPrice} 
          />
        )}
        {currentView === 'MY_ORDERS' && (
          <MyOrders 
            currentUser={currentUser} 
            ordersDb={ordersDb} 
            onNavigate={navigateTo} 
            formatPrice={formatPrice} 
            onSetReviewingItem={setReviewingItem} 
            onSetCancellingOrder={setCancellingOrder} 
            onSetReturningOrder={setReturningOrder} 
          />
        )}
        {currentView === 'ACCOUNT' && (
          <AccountView 
            currentUser={currentUser} 
            accountForm={accountForm} 
            onFormChange={setAccountForm} 
            onSubmit={handleUpdateAccount} 
            onLogout={handleLogout} 
            onDeleteAccount={() => setShowDeleteAccountModal(true)} 
          />
        )}
        {currentView === 'CHECKOUT' && (
          <Checkout 
            currentUser={currentUser} 
            cart={cart} 
            productsDb={productsDb} 
            checkoutData={checkoutData} 
            setCheckoutData={setCheckoutData} 
            onPlaceOrder={handlePlaceOrder} 
            onNavigate={navigateTo} 
            formatPrice={formatPrice} 
            cartTotal={cartTotal} 
            shippingFee={shippingFee} 
            orderTotal={orderTotal} 
          />
        )}
        {(currentView === 'LOGIN' || currentView === 'SIGNUP') && (
          <AuthView 
            isLogin={currentView === 'LOGIN'} 
            authForm={authForm} 
            onFormChange={setAuthForm} 
            onSubmit={currentView === 'LOGIN' ? handleLogin : handleSignup} 
            onNavigate={navigateTo} 
            onGoogleLogin={handleGoogleLogin}
          />
        )}
        {currentView === 'SUCCESS' && <SuccessView onNavigate={navigateTo} />}
        {currentView === 'ADMIN_PANEL' && (
          <AdminPanel 
            adminTab={adminTab} setAdminTab={setAdminTab} isAdminSidebarOpen={isAdminSidebarOpen} setIsAdminSidebarOpen={setIsAdminSidebarOpen}
            ordersDb={ordersDb} productsDb={productsDb} usersDb={usersDb} manualRevenues={manualRevenues}
            revenueSearchQuery={revenueSearchQuery} setRevenueSearchQuery={setRevenueSearchQuery}
            manualRevenueSearchQuery={manualRevenueSearchQuery} setManualRevenueSearchQuery={setManualRevenueSearchQuery}
            revenueForm={revenueForm} setRevenueForm={setRevenueForm} adminSettingsForm={adminSettingsForm} setAdminSettingsForm={setAdminSettingsForm}
            newProductForm={newProductForm} setNewProductForm={setNewProductForm} onLogout={handleLogout}
            onAddManualRevenue={handleAddManualRevenue} onDeleteManualRevenue={deleteManualRevenue} onAddProduct={handleAddProduct}
            onUpdateStock={handleUpdateStock} onDeleteProduct={deleteProduct} onUpdateProductImage={updateProductImage}
            onOpenPriceEdit={handleOpenPriceEdit} onPasswordChange={handlePasswordChange} onRazorpayUpdate={handleRazorpayUpdate}
            onBannerUpload={handleBannerUpload} onRemoveBanner={handleRemoveBanner} onOrderStatusChange={handleOrderStatusChange}
            bannerImage={globalSettings.bannerImage} formatPrice={formatPrice} onMediaUpload={handleMediaUpload} onRemoveMedia={removeMedia}
            topBannerText={globalSettings.topBannerText} privacyPolicy={globalSettings.privacyPolicy} termsOfService={globalSettings.termsOfService}
            onUpdateLegalAndBanner={handleUpdateLegalAndBanner} notesDb={notesDb} onAddNote={handleAddNote} onDeleteNote={deleteNote}
          />
        )}
        {currentView === 'ADMIN_LOGIN' && (
          <div className="min-h-[70vh] flex items-center justify-center px-4 animate-fade-in bg-black">
            <div className="w-full max-w-md bg-[#111] p-10 border border-[#333] shadow-2xl">
              <div className="flex justify-center mb-6"><Crown className="w-12 h-12 text-[#C5A059]" /></div>
              <h2 className="text-2xl font-serif text-center text-white mb-8 tracking-widest uppercase">Akaay Enterprise Admin Portal</h2>
              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div><label className="block text-xs tracking-widest uppercase text-gray-400 mb-2 font-bold">Admin ID</label><input required type="text" placeholder="e.g. akaayadmin" value={adminLoginForm.id} onChange={e => setAdminLoginForm({...adminLoginForm, id: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#444] text-white py-3 px-4 focus:outline-none focus:border-[#C5A059] transition-colors" /></div>
                <div><label className="block text-xs tracking-widest uppercase text-gray-400 mb-2 font-bold">Password</label><input required type="password" value={adminLoginForm.password} onChange={e => setAdminLoginForm({...adminLoginForm, password: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#444] text-white py-3 px-4 focus:outline-none focus:border-[#C5A059] transition-colors" /></div>
                <button type="submit" className="w-full bg-[#C5A059] text-white py-4 tracking-[0.2em] text-sm uppercase hover:bg-white hover:text-black transition-colors font-bold mt-4">Access Wholesale Panel</button>
              </form>
              <div className="mt-8 text-center border-t border-[#333] pt-6"><button onClick={() => navigateTo('HOME')} className="text-xs tracking-widest uppercase text-gray-500 hover:text-[#C5A059] transition-colors font-bold">Return to Shop</button></div>
            </div>
          </div>
        )}
        {currentView === 'PRIVACY_POLICY' && <PrivacyPolicy content={globalSettings.privacyPolicy} />}
        {currentView === 'TERMS_OF_SERVICE' && <TermsOfService content={globalSettings.termsOfService} />}
        {currentView === 'CONTACT' && <ContactView onNavigate={navigateTo} onShowToast={showToast} />}
      </main>

      {renderEditPriceModal()}

      {currentView !== 'ADMIN_PANEL' && currentView !== 'ADMIN_LOGIN' && (
        <>
          <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} searchQuery={searchQuery} onSearchChange={setSearchQuery} productsDb={productsDb} onNavigate={navigateTo} />
          <CartDrawer isOpen={isCartDrawerOpen} onClose={() => setIsCartDrawerOpen(false)} cart={cart} productsDb={productsDb} onRemove={removeFromCart} onUpdateQuantity={updateQuantity} onCheckout={() => { setIsCartDrawerOpen(false); navigateTo('CHECKOUT'); }} />
          <CancelOrderModal isOpen={!!cancellingOrder} onClose={() => { setCancellingOrder(null); setCancelReason(''); }} order={cancellingOrder} reason={cancelReason} onReasonChange={setCancelReason} onSubmit={submitCancellation} />
          <ReturnOrderModal isOpen={!!returningOrder} onClose={() => { setReturningOrder(null); setReturnReason(''); }} order={returningOrder} reason={returnReason} onReasonChange={setReturnReason} onSubmit={submitReturn} />
          <ReviewModal isOpen={!!reviewingItem} onClose={() => { setReviewingItem(null); setReviewForm({rating: 5, comment: '', image: ''}); }} item={reviewingItem} form={reviewForm} onFormChange={setReviewForm} onImageUpload={handleReviewImageUpload} onSubmit={submitReview} />
          <DeleteAccountModal isOpen={showDeleteAccountModal} onClose={() => { setShowDeleteAccountModal(false); setDeleteAccountReason(''); }} reason={deleteAccountReason} onReasonChange={setDeleteAccountReason} onSubmit={handleConfirmDeleteAccount} />
          <Footer onNavigate={navigateTo} />
        </>
      )}
    </div>
    </>
  );
}
