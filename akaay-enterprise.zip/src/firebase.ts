const API_BASE = '/api';

export const db = { isMock: true };
export const auth = { currentUser: null };
export const isFirebaseEnabled = true;

class CollectionRef {
  constructor(public name: string) {}
}

class DocRef {
  constructor(public collectionName: string, public id: string) {}
}

export const collection = (dbInstance: any, name: string) => {
  return new CollectionRef(name);
};

export const doc = (dbInstance: any, collectionName: string, id: string) => {
  return new DocRef(collectionName, id);
};

export const setDoc = async (docRef: DocRef, data: any, options?: any) => {
  await fetch(`${API_BASE}/${docRef.collectionName}/${docRef.id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ data, merge: options?.merge })
  });
};

export const deleteDoc = async (docRef: DocRef) => {
  await fetch(`${API_BASE}/${docRef.collectionName}/${docRef.id}`, {
    method: 'DELETE'
  });
};

export const getDocs = async (collectionRef: any) => {
  const colName = collectionRef instanceof CollectionRef ? collectionRef.name : (collectionRef.collectionName || '');
  const res = await fetch(`${API_BASE}/${colName}`);
  const data = await res.json();
  const docs = Object.keys(data).map(id => ({
    id,
    data: () => data[id]
  }));
  return {
    forEach: (cb: any) => docs.forEach(cb),
    docs
  };
};

export const getDoc = async (docRef: DocRef) => {
  const res = await fetch(`${API_BASE}/${docRef.collectionName}/${docRef.id}`);
  const data = await res.json();
  return {
    exists: () => !!data,
    data: () => data
  };
};

export const query = (colRef: CollectionRef, ...args: any[]) => {
  return colRef;
};

export const orderBy = (field: string, direction: string) => {
  return { field, direction };
};

const snapshotSubscribers = new Map<string, Set<Function>>();
const pollingIntervals = new Map<string, any>();

export const onSnapshot = (ref: any, onNext: (snapshot: any) => void, onError?: (error: any) => void) => {
  const isDoc = ref instanceof DocRef;
  const url = isDoc ? `${API_BASE}/${ref.collectionName}/${ref.id}` : `${API_BASE}/${ref.name}`;
  const key = url;

  if (!snapshotSubscribers.has(key)) {
    snapshotSubscribers.set(key, new Set());
    
    const poll = async () => {
      try {
         const res = await fetch(url);
         const data = await res.json();
         
         const snapshot = isDoc ? {
           exists: () => !!data && Object.keys(data).length > 0,
           data: () => data,
           id: ref.id
         } : {
           forEach: (cb: any) => {
             Object.keys(data || {}).forEach(id => cb({ id, data: () => data[id] }));
           }
         };

         snapshotSubscribers.get(key)?.forEach(cb => cb(snapshot));
      } catch (err) {
         if (onError) onError(err);
      }
    };
    
    poll();
    pollingIntervals.set(key, setInterval(poll, 3000));
  }

  snapshotSubscribers.get(key)!.add(onNext);

  return () => {
    const subs = snapshotSubscribers.get(key);
    if (subs) {
      subs.delete(onNext);
      if (subs.size === 0) {
        clearInterval(pollingIntervals.get(key));
        pollingIntervals.delete(key);
        snapshotSubscribers.delete(key);
      }
    }
  };
};

export class GoogleAuthProvider {}
export const signInWithPopup = async (authInstance: any, provider: any) => {
  const email = prompt("To login, please enter your email address:");
  if (!email) throw new Error("Sign in cancelled");
  
  const name = prompt("Enter your name (optional):") || email.split('@')[0];
  
  return {
    user: {
      uid: email,
      displayName: name,
      email: email
    }
  };
};
