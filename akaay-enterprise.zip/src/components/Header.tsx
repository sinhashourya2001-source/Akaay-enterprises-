import React from 'react';
import { Menu, Search, User, ShoppingBag } from 'lucide-react';
import { User as UserType } from '../types';

interface HeaderProps {
  currentUser: UserType | null;
  cartCount: number;
  onNavigate: (view: string) => void;
  onOpenMobileMenu: () => void;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onCategoryClick: (category: string) => void;
  topBannerText?: string;
}

export default function Header({ 
  currentUser, cartCount, onNavigate, onOpenMobileMenu, onOpenCart, onOpenSearch, onCategoryClick, topBannerText 
}: HeaderProps) {
  return (
    <>
      <div className="bg-black text-[#C5A059] text-[10px] text-center py-3 tracking-[0.2em] font-bold uppercase border-b border-[#333]">
        {topBannerText || "Complimentary Shipping on orders over ₹1,000"}
      </div>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-sm py-5 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <button className="lg:hidden p-2 -ml-2 text-black" onClick={onOpenMobileMenu}><Menu className="w-6 h-6" /></button>
            <nav className="hidden lg:flex space-x-8 text-[11px] tracking-[0.15em] text-gray-500 font-bold uppercase">
              <button onClick={() => { onCategoryClick('All'); onNavigate('HOME'); }} className="hover:text-black transition-colors">Products</button>
              <button onClick={() => onNavigate('MY_ORDERS')} className="hover:text-black transition-colors">Orders</button>
              <button onClick={() => onCategoryClick('Beverages')} className="hover:text-black transition-colors">Beverages</button>
              <button onClick={() => onCategoryClick('Chocolates')} className="hover:text-black transition-colors">Chocolates</button>
            </nav>
          </div>
          
          <button 
            onClick={() => { onCategoryClick('All'); onNavigate('HOME'); }} 
            onDoubleClick={() => onNavigate('ADMIN_LOGIN')} 
            title="Double click for admin management" 
            className="text-2xl md:text-4xl font-serif tracking-[0.2em] font-bold text-center absolute left-1/2 transform -translate-x-1/2 uppercase select-none cursor-pointer text-black"
          >
            Akaay Enterprise
          </button>

          <div className="flex items-center space-x-5 md:space-x-8 text-black">
            <button onClick={onOpenSearch} className="hover:text-[#C5A059] transition-colors" title="Search Wholesale"><Search className="w-5 h-5" /></button>
            {currentUser ? (
              <div className="hidden sm:flex items-center space-x-5">
                <button onClick={() => onNavigate('ACCOUNT')} className="flex items-center text-[10px] uppercase tracking-widest font-bold text-gray-500 hover:text-black transition-colors cursor-pointer"><User className="w-4 h-4 mr-2" /> My Account</button>
              </div>
            ) : (
              <button onClick={() => onNavigate('LOGIN')} className="hidden sm:block hover:text-[#C5A059] transition-colors" title="Wholesaler Access"><User className="w-5 h-5" /></button>
            )}
            <button className="relative hover:text-[#C5A059] transition-colors p-2 -mr-2" onClick={onOpenCart}>
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && <span className="absolute top-0 right-0 bg-black text-[#C5A059] text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold border border-[#C5A059]">{cartCount}</span>}
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
