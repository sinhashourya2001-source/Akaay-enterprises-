import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, AlertCircle, Star, Image as ImageIcon } from 'lucide-react';
import { Order } from '../types';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  type?: 'danger' | 'warning' | 'info';
}

const BaseModal = ({ isOpen, onClose, title, children, footer, type = 'info' }: ModalProps) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white w-full max-w-md border border-gray-200 shadow-2xl p-10"
        >
          <div className="flex items-center justify-between mb-8">
            <h2 className={`text-2xl font-serif uppercase tracking-widest ${type === 'danger' ? 'text-red-600' : type === 'warning' ? 'text-orange-600' : 'text-black'}`}>
              {title}
            </h2>
            <button onClick={onClose}><X className="text-gray-400 hover:text-black w-6 h-6" /></button>
          </div>
          {children}
          {footer && <div className="mt-10 flex flex-col gap-4">{footer}</div>}
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

export const CancelOrderModal = ({ 
  order, isOpen, onClose, reason, onReasonChange, onSubmit 
}: { order: Order | null, isOpen: boolean, onClose: () => void, reason: string, onReasonChange: (v: string) => void, onSubmit: () => void }) => (
  <BaseModal isOpen={isOpen} onClose={onClose} title="Cancel Order" type="danger" footer={
    <>
      <button onClick={onSubmit} className="w-full bg-red-700 text-white py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-red-800 transition-colors">Confirm Cancellation</button>
      <button onClick={onClose} className="w-full border border-gray-300 text-black py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-gray-100 transition-colors">Abort Cancellation</button>
    </>
  }>
    <p className="text-sm text-gray-600 mb-8 leading-relaxed text-center">You are about to cancel order <span className="font-mono font-bold text-black">#{order?.orderId}</span>. Please detail your reasoning below.</p>
    <div className="space-y-4">
      <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2 font-bold">Reason for Cancellation</label>
      <textarea autoFocus value={reason} onChange={(e) => onReasonChange(e.target.value)} placeholder="Provide a brief explanation..." className="w-full border border-gray-300 p-4 text-sm focus:outline-none focus:border-red-600 bg-gray-50 resize-none transition-colors" rows={4} />
    </div>
  </BaseModal>
);

export const ReturnOrderModal = ({ 
  order, isOpen, onClose, reason, onReasonChange, onSubmit 
}: { order: Order | null, isOpen: boolean, onClose: () => void, reason: string, onReasonChange: (v: string) => void, onSubmit: () => void }) => (
  <BaseModal isOpen={isOpen} onClose={onClose} title="Request Return" type="warning" footer={
    <>
      <button onClick={onSubmit} className="w-full bg-orange-700 text-white py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-orange-800 transition-colors">Submit Return Request</button>
      <button onClick={onClose} className="w-full border border-gray-300 text-black py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-gray-100 transition-colors">Cancel Request</button>
    </>
  }>
    <p className="text-sm text-gray-600 mb-8 leading-relaxed text-center">Initiating return for order <span className="font-mono font-bold text-black">#{order?.orderId}</span>. Wholesale returns must be approved by our team.</p>
    <div className="space-y-4">
      <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2 font-bold">Return Justification</label>
      <textarea autoFocus value={reason} onChange={(e) => onReasonChange(e.target.value)} placeholder="Detail any damage or discrepancy..." className="w-full border border-gray-300 p-4 text-sm focus:outline-none focus:border-orange-600 bg-gray-50 resize-none transition-colors" rows={4} />
    </div>
  </BaseModal>
);

export const ReviewModal = ({ 
  item, isOpen, onClose, form, onFormChange, onImageUpload, onSubmit 
}: { item: any, isOpen: boolean, onClose: () => void, form: any, onFormChange: (v: any) => void, onImageUpload: (e: any) => void, onSubmit: () => void }) => (
  <BaseModal isOpen={isOpen} onClose={onClose} title="Review Product" footer={
    <button onClick={onSubmit} className="w-full bg-black text-[#C5A059] py-5 tracking-[0.2em] text-xs uppercase font-bold hover:bg-[#C5A059] hover:text-white transition-colors border border-black">Publish Review</button>
  }>
    <p className="text-sm text-[#C5A059] mb-8 font-bold uppercase tracking-wider">Piece: {item?.name}</p>
    <div className="space-y-8">
      <div>
        <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-3 font-bold">Product Rating</label>
        <div className="flex gap-3">{[1, 2, 3, 4, 5].map((star) => (<button key={star} onClick={() => onFormChange({...form, rating: star})}><Star className={`w-8 h-8 transition-colors ${form.rating >= star ? 'text-[#C5A059] fill-current' : 'text-gray-200'}`} /></button>))}</div>
      </div>
      <div><label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-3 font-bold">Customer Remarks</label><textarea value={form.comment} onChange={(e) => onFormChange({...form, comment: e.target.value})} placeholder="Share your experience with this product..." className="w-full border border-gray-300 p-4 text-sm focus:outline-none focus:border-black bg-gray-50 resize-none transition-colors" rows={4} /></div>
      <div>
        <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-3 font-bold">Installation Photo (Optional)</label>
        <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 bg-gray-50 cursor-pointer hover:bg-gray-100 transition-colors overflow-hidden">
          <input type="file" accept="image/*" onChange={onImageUpload} className="hidden" />
          {form.image ? <img src={form.image} alt="Review" className="w-full h-full object-cover" /> : <div className="text-center text-gray-500"><ImageIcon className="w-6 h-6 mx-auto mb-2 text-[#C5A059]" /><span className="text-[10px] uppercase tracking-widest font-bold">Upload Image</span></div>}
        </label>
      </div>
    </div>
  </BaseModal>
);

export const DeleteAccountModal = ({ 
  isOpen, onClose, reason, onReasonChange, onSubmit 
}: { isOpen: boolean, onClose: () => void, reason: string, onReasonChange: (v: string) => void, onSubmit: () => void }) => (
  <BaseModal isOpen={isOpen} onClose={onClose} title="Delete Account" type="danger" footer={
    <>
      <button onClick={onSubmit} className="w-full bg-red-700 text-white py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-red-800 transition-colors">Confirm Deletion</button>
      <button onClick={onClose} className="w-full border border-gray-300 text-black py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-gray-100 transition-colors">Cancel</button>
    </>
  }>
    <p className="text-sm text-gray-600 mb-8 leading-relaxed text-center">You are about to permanently delete your account. This will remove all your order history and personal details.</p>
    <div className="space-y-4">
      <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2 font-bold">Reason for Leaving</label>
      <textarea autoFocus value={reason} onChange={(e) => onReasonChange(e.target.value)} placeholder="Please let us know why you are deleting your account..." className="w-full border border-gray-300 p-4 text-sm focus:outline-none focus:border-red-600 bg-gray-50 resize-none transition-colors" rows={4} />
    </div>
  </BaseModal>
);
