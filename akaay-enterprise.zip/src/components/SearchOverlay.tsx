import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X } from 'lucide-react';
import { Product } from '../types';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  productsDb: Product[];
  onNavigate: (view: string, id?: string | number) => void;
}

export default function SearchOverlay({ 
  isOpen, onClose, searchQuery, onSearchChange, productsDb, onNavigate 
}: SearchOverlayProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  const filteredProducts = productsDb.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-white/95 backdrop-blur-md flex flex-col"
        >
          <div className="flex items-center p-6 md:p-12 border-b border-gray-200">
            <Search className="w-8 h-8 text-black mr-6" />
            <input 
              autoFocus 
              type="text" 
              placeholder="Search the gallery..." 
              value={searchQuery} 
              onChange={(e) => onSearchChange(e.target.value)}
              className="flex-1 bg-transparent text-2xl md:text-5xl font-serif text-black focus:outline-none placeholder:text-gray-300"
            />
            <button onClick={onClose} className="ml-6 p-2 text-gray-500 hover:text-black transition-colors">
              <X className="w-8 h-8 md:w-10 md:h-10" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 md:p-12 custom-scrollbar">
            {searchQuery.trim() === '' ? (
              <div className="text-center text-gray-500 mt-20 text-lg font-serif">Type to search the collection...</div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
                {filteredProducts.map(product => (
                  <div key={product.id} className="cursor-pointer group flex flex-col" onClick={() => onNavigate('PRODUCT', product.id)}>
                    <div className="relative overflow-hidden bg-gray-100 aspect-[3/4] mb-4">
                      {product.mainMediaType === 'video' ? (
                        <video src={product.image} autoPlay muted loop playsInline className={`w-full h-full object-cover transition-transform duration-700 ${product.inStock ? 'group-hover:scale-105' : 'opacity-70'}`} />
                      ) : (
                        <img src={product.image} className={`w-full h-full object-cover transition-transform duration-700 ${product.inStock ? 'group-hover:scale-105' : 'opacity-70'}`} alt={product.name} />
                      )}
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-white/40 flex items-center justify-center"><span className="bg-white/90 text-black px-3 py-1 text-[10px] uppercase tracking-widest font-bold">Sold Out</span></div>
                      )}
                    </div>
                    <p className="text-gray-500 text-[10px] tracking-widest uppercase mb-1">{product.category}</p>
                    <h3 className="text-sm font-medium text-black mb-2">{product.name}</h3>
                    <p className="text-sm text-gray-700">{formatPrice(product.price)}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-gray-500 mt-20 text-lg font-serif">No pieces found matching "{searchQuery}"</div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
