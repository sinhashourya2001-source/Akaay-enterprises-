import React from 'react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-black text-white pt-20 pb-10 border-t border-[#333] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center md:text-left">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-16">
          <div>
            <div className="text-2xl font-serif tracking-[0.2em] font-bold uppercase mb-6 text-[#C5A059]">Akaay Enterprise</div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs mx-auto md:mx-0 font-light">Premium wholesale distributor of beverages, chocolates, and bulk supplies for retail and businesses worldwide.</p>
          </div>
          <div>
            <h4 className="text-[10px] font-bold tracking-widest uppercase mb-8 text-gray-300">Wholesale Services</h4>
            <ul className="space-y-4 text-xs text-gray-500 font-bold uppercase tracking-wider">
              <li><button onClick={() => onNavigate('MY_ORDERS')} className="hover:text-[#C5A059] transition-colors text-left">Track Order</button></li>
              <li><button onClick={() => onNavigate('CONTACT')} className="hover:text-[#C5A059] transition-colors text-left">Contact Sales</button></li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-[#333] text-[10px] font-bold uppercase tracking-widest text-gray-600 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} Akaay Enterprise. All rights reserved.</p>
          <div className="flex space-x-6 mt-6 md:mt-0">
            <button onClick={() => onNavigate('PRIVACY_POLICY')} className="hover:text-white cursor-pointer transition-colors uppercase tracking-widest">Privacy Policy</button>
            <button onClick={() => onNavigate('TERMS_OF_SERVICE')} className="hover:text-white cursor-pointer transition-colors uppercase tracking-widest">Terms of Service</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
