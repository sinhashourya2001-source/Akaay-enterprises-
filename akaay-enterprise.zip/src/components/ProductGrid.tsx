import React from 'react';
import { Product } from '../types';

interface ProductGridProps {
  products: Product[];
  title: string;
  onProductClick: (id: string | number) => void;
  onAddToCart: (product: Product) => void;
  isLoading?: boolean;
}

export default function ProductGrid({ products, title, onProductClick, onAddToCart, isLoading = false }: ProductGridProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  if (isLoading) {
    return (
      <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto flex-1">
        <h2 className="text-3xl font-serif text-black mb-10 text-center md:text-left"><div className="h-8 bg-gray-200 w-48 inline-block animate-pulse"></div></h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-12 md:gap-x-8">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="flex flex-col animate-pulse">
              <div className="bg-gray-200 aspect-[3/4] mb-4 w-full"></div>
              <div className="h-3 bg-gray-200 mb-2 w-1/3"></div>
              <div className="h-4 bg-gray-200 mb-2 w-3/4 flex-1"></div>
              <div className="h-4 bg-gray-200 mt-auto w-1/4"></div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <h2 className="text-3xl font-serif text-black mb-10 text-center md:text-left">{title}</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-12 md:gap-x-8">
        {products.map((product) => (
          <div key={product.id} className="group flex flex-col cursor-pointer" onClick={() => onProductClick(product.id)}>
            <div className="relative overflow-hidden bg-gray-100 aspect-[3/4] mb-4">
              {product.isNew && <span className="absolute top-3 left-3 bg-black text-white text-[9px] tracking-widest uppercase px-2 py-1 z-10">New Work</span>}
              
              {product.mainMediaType === 'video' ? (
                <video src={product.image} autoPlay muted loop playsInline className={`w-full h-full object-cover object-center transition-transform duration-700 ${product.inStock ? 'group-hover:scale-105' : 'opacity-60'}`} />
              ) : (
                <img src={product.image} alt={product.name} className={`w-full h-full object-cover object-center transition-transform duration-700 ${product.inStock ? 'group-hover:scale-105' : 'opacity-60'}`} />
              )}
              
              {!product.inStock && (
                <div className="absolute inset-0 bg-white/40 flex items-center justify-center z-10"><span className="bg-black text-white px-4 py-2 text-[10px] uppercase tracking-[0.2em] font-bold">Sold</span></div>
              )}

              {product.inStock && (
                <div className="absolute inset-x-0 bottom-0 p-4 opacity-0 transform translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 z-20">
                  <button 
                    onClick={(e) => { e.stopPropagation(); onAddToCart(product); }} 
                    className="w-full bg-white/95 text-black py-3 text-xs tracking-widest uppercase hover:bg-black hover:text-white transition-colors shadow-sm font-bold"
                  >
                    Buy
                  </button>
                </div>
              )}
            </div>
            <div className="text-center md:text-left flex flex-col flex-1">
              <p className="text-gray-500 text-[10px] tracking-widest uppercase mb-1">{product.category}</p>
              <h3 className="text-sm font-medium text-black mb-2 leading-tight">{product.name}</h3>
              {product.originalPrice ? (
                <p className="text-sm mt-auto">
                  <span className="text-gray-400 line-through mr-2 font-light">{formatPrice(product.originalPrice)}</span>
                  <span className="text-red-600 font-bold">{formatPrice(product.price)}</span>
                </p>
              ) : (
                <p className="text-sm text-gray-700 mt-auto">{formatPrice(product.price)}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
