import React from 'react';
import { User, ShoppingBag, CreditCard, Smartphone, Truck, Lock } from 'lucide-react';
import { Product, User as UserType } from '../types';

interface CheckoutProps {
  currentUser: UserType | null;
  cart: (Product & { quantity: number })[];
  productsDb: Product[];
  checkoutData: any;
  setCheckoutData: (d: any) => void;
  onPlaceOrder: (e: React.FormEvent) => void;
  onNavigate: (v: string) => void;
  formatPrice: (price: number) => string;
  cartTotal: number;
  shippingFee: number;
  orderTotal: number;
}

export default function Checkout({ 
  currentUser, cart, productsDb, checkoutData, setCheckoutData, onPlaceOrder, onNavigate, formatPrice, cartTotal, shippingFee, orderTotal 
}: CheckoutProps) {
  if (!currentUser) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4"><User className="w-16 h-16 text-gray-300 mb-6" /><h2 className="text-2xl font-serif mb-4 uppercase tracking-widest text-black">Wholesaler Login Required</h2><button onClick={() => onNavigate('LOGIN')} className="bg-black text-white px-10 py-4 tracking-[0.2em] text-sm uppercase font-bold hover:bg-[#C5A059] transition-colors">Log In</button></div>
  );
  if (cart.length === 0) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4"><ShoppingBag className="w-16 h-16 text-gray-300 mb-6" /><h2 className="text-2xl font-serif mb-4 uppercase tracking-widest text-black">Your cart is empty</h2><button onClick={() => onNavigate('HOME')} className="border border-black text-black px-10 py-4 tracking-[0.2em] text-sm font-bold uppercase hover:bg-black hover:text-white transition-colors">Return to Shop</button></div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 animate-fade-in">
      <h1 className="text-3xl font-serif text-black mb-16 text-center uppercase tracking-wider">Secure Checkout</h1>
      <div className="flex flex-col lg:flex-row gap-16">
        <div className="flex-1 space-y-12">
          <section>
            <h2 className="text-lg font-serif tracking-widest uppercase mb-8 pb-4 border-b border-gray-200">1. Shipping & Crating Destination</h2>
            <form className="space-y-6">
              <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Full Address</label><textarea required value={checkoutData.address} onChange={e => setCheckoutData({...checkoutData, address: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" rows={3}></textarea></div>
              <div className="grid grid-cols-2 gap-8">
                <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">City</label><input required type="text" value={checkoutData.city} onChange={e => setCheckoutData({...checkoutData, city: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" /></div>
                <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Postal Code</label><input required type="text" value={checkoutData.pincode} onChange={e => setCheckoutData({...checkoutData, pincode: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" /></div>
              </div>
              <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Phone Number</label><input required type="tel" value={checkoutData.phone} onChange={e => setCheckoutData({...checkoutData, phone: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" /></div>
            </form>
          </section>
          <section>
            <h2 className="text-lg font-serif tracking-widest uppercase mb-8 pb-4 border-b border-gray-200">2. Payment Method</h2>
            <div className="space-y-4">
              <label className={`flex items-center p-6 border cursor-pointer transition-colors ${checkoutData.paymentMethod === 'CARD' ? 'border-black bg-gray-50' : 'border-gray-200 hover:border-gray-400'}`}><input type="radio" name="payment" checked={checkoutData.paymentMethod === 'CARD'} onChange={() => setCheckoutData({...checkoutData, paymentMethod: 'CARD'})} className="mr-6 accent-black" /><CreditCard className="w-6 h-6 mr-4 text-black" /><span className="flex-1 font-bold uppercase tracking-wider text-sm">Credit / Debit Card</span></label>
              <label className={`flex items-center p-6 border cursor-pointer transition-colors ${checkoutData.paymentMethod === 'ONLINE' ? 'border-black bg-gray-50' : 'border-gray-200 hover:border-gray-400'}`}><input type="radio" name="payment" checked={checkoutData.paymentMethod === 'ONLINE'} onChange={() => setCheckoutData({...checkoutData, paymentMethod: 'ONLINE'})} className="mr-6 accent-black" /><Smartphone className="w-6 h-6 mr-4 text-black" /><span className="flex-1 font-bold uppercase tracking-wider text-sm">Bank Transfer / Wire</span></label>
              <label className={`flex items-center p-6 border transition-colors ${orderTotal > 2000 ? 'opacity-50 cursor-not-allowed bg-gray-50 border-gray-200' : checkoutData.paymentMethod === 'COD' ? 'border-black bg-gray-50 cursor-pointer' : 'border-gray-200 hover:border-gray-400 cursor-pointer'}`}><input type="radio" name="payment" disabled={orderTotal > 2000} checked={checkoutData.paymentMethod === 'COD'} onChange={() => { if(orderTotal <= 2000) setCheckoutData({...checkoutData, paymentMethod: 'COD'}) }} className="mr-6 accent-black disabled:accent-gray-300" /><Truck className="w-6 h-6 mr-4 text-black" /><div className="flex-1 flex flex-col"><span className="font-bold uppercase tracking-wider text-sm">Pay on Delivery</span>{orderTotal > 2000 && <span className="text-[10px] text-red-500 uppercase tracking-widest mt-1 font-bold">Not available for orders over ₹2,000</span>}</div></label>
            </div>
          </section>
        </div>

        <div className="w-full lg:w-1/3">
          <div className="bg-gray-50 p-8 sticky top-28 border border-gray-200">
            <h3 className="text-lg font-serif tracking-widest uppercase mb-8 text-black">Acquisition Summary</h3>
            <div className="space-y-6 mb-8 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
              {cart.map(item => {
                const isItemInStock = productsDb.find(p => p.id === item.id)?.inStock !== false;
                return (
                <div key={item.id} className={`flex justify-between items-center ${!isItemInStock ? 'opacity-50' : ''}`}>
                  <div className="flex items-center">
                    {item.mainMediaType === 'video' ? <video src={item.image} autoPlay muted loop playsInline className="w-16 h-20 object-cover border border-gray-200 mr-4" /> : <img src={item.image} alt={item.name} className="w-16 h-20 object-cover border border-gray-200 mr-4" />}
                    <div><p className="text-sm font-bold uppercase tracking-wide leading-tight line-clamp-2 mb-1">{item.name}</p>{!isItemInStock && <span className="text-red-600 text-[10px] uppercase tracking-widest font-bold">Sold Out</span>}<p className="text-xs text-gray-500 uppercase tracking-widest">Qty: {item.quantity}</p></div>
                  </div>
                  <p className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</p>
                </div>
              )})}
            </div>
            <div className="border-t border-gray-300 pt-6 space-y-4 text-sm font-medium">
              <div className="flex justify-between text-gray-600 uppercase tracking-widest text-xs"><span>Subtotal</span> <span>{formatPrice(cartTotal)}</span></div>
              <div className="flex justify-between text-gray-600 uppercase tracking-widest text-xs"><span>Freight & Handling</span> <span>{shippingFee === 0 ? 'Complimentary' : formatPrice(shippingFee)}</span></div>
              <div className="flex justify-between font-serif text-xl text-black pt-4 mt-4 border-t border-black"><span className="uppercase tracking-widest">Total</span> <span>{formatPrice(orderTotal)}</span></div>
            </div>
            {cart.some(item => productsDb.find(p => p.id === item.id)?.inStock === false) ? (
              <button disabled className="w-full bg-gray-200 text-gray-500 cursor-not-allowed py-5 mt-10 tracking-[0.2em] text-sm uppercase font-bold flex justify-center items-center">Review Sold Out Works</button>
            ) : (
              <button onClick={onPlaceOrder} className="w-full bg-black text-[#C5A059] py-5 mt-10 tracking-[0.2em] text-sm uppercase font-bold hover:bg-[#C5A059] hover:text-white transition-colors">{checkoutData.paymentMethod === 'COD' ? 'Confirm Order' : 'Proceed to Payment'}</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
