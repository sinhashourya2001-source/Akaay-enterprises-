import React from 'react';
import { ArrowLeft, ShieldCheck, Truck, Star, User, ShoppingBag, Package, LogOut, AlertCircle, CreditCard, Smartphone, Crown, CheckCircle2 } from 'lucide-react';
import { Product, Order, User as UserType } from '../types';

interface ProductDetailsProps {
  product: Product;
  activeMediaIdx: number;
  setActiveMediaIdx: (idx: number) => void;
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
  onNavigate: (view: string) => void;
  formatPrice: (price: number) => string;
}

export const ProductDetails = ({ product, activeMediaIdx, setActiveMediaIdx, onAddToCart, onBuyNow, onNavigate, formatPrice }: ProductDetailsProps) => {
  const relatedProducts: Product[] = []; // This would ideally be passed in or fetched
  const productMedia = product.media && product.media.length > 0 ? product.media : [{ id: 0, type: product.mainMediaType, url: product.image }];

  return (
    <div className="animate-fade-in pt-10 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button onClick={() => onNavigate('HOME')} className="flex items-center text-sm text-gray-500 hover:text-[#C5A059] mb-8 transition-colors uppercase tracking-widest font-bold">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Shop
        </button>

        <div className="flex flex-col md:flex-row gap-12 lg:gap-20">
          <div className="w-full md:w-1/2 flex flex-col gap-4">
            <div className="relative w-full aspect-[4/5] bg-gray-100 overflow-hidden border border-gray-200 shadow-sm">
              {productMedia[activeMediaIdx]?.type === 'video' ? (
                <video src={productMedia[activeMediaIdx].url} controls autoPlay muted loop className={`w-full h-full object-cover ${!product.inStock ? 'opacity-70' : ''}`} />
              ) : (
                <img src={productMedia[activeMediaIdx]?.url} alt={product.name} className={`w-full h-full object-cover ${!product.inStock ? 'opacity-70' : ''}`} />
              )}
              {!product.inStock && <div className="absolute top-4 right-4 bg-black text-white px-4 py-2 text-xs uppercase tracking-[0.2em] font-bold z-10">Sold Out</div>}
            </div>
            
            {productMedia.length > 1 && (
              <div className="flex gap-4 overflow-x-auto pb-2 custom-scrollbar">
                {productMedia.map((mediaItem, idx) => (
                  <button key={idx} onClick={() => setActiveMediaIdx(idx)} className={`relative shrink-0 w-20 h-24 overflow-hidden border-2 transition-colors ${activeMediaIdx === idx ? 'border-black' : 'border-transparent hover:border-gray-300'}`}>
                    {mediaItem.type === 'video' ? <video src={mediaItem.url} className="w-full h-full object-cover" /> : <img src={mediaItem.url} className="w-full h-full object-cover" />}
                    {mediaItem.type === 'video' && <div className="absolute inset-0 bg-black/20 flex items-center justify-center"><div className="w-6 h-6 rounded-full bg-white/80 flex items-center justify-center pl-0.5 text-black/80">▶</div></div>}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="w-full md:w-1/2 flex flex-col justify-center">
            <p className="text-[#C5A059] text-xs tracking-widest uppercase mb-2 font-bold">{product.category}</p>
            <h1 className="text-3xl md:text-5xl font-serif text-black mb-4 uppercase tracking-wide">{product.name}</h1>
            <p className="text-sm uppercase tracking-widest text-gray-500 mb-6 border-b border-gray-200 pb-4">By Akaay Enterprise Original</p>
            
            <div className="flex items-center gap-4 mb-8">
              {product.originalPrice ? (
                <><span className="text-2xl text-gray-400 line-through font-light">{formatPrice(product.originalPrice)}</span><span className="text-3xl text-red-600 font-bold">{formatPrice(product.price)}</span></>
              ) : (
                <p className="text-3xl text-black font-light">{formatPrice(product.price)}</p>
              )}
            </div>

            <p className="text-gray-700 leading-relaxed mb-10 font-light">{product.description}</p>

            <button onClick={() => onAddToCart(product)} disabled={!product.inStock} className={`w-full py-4 tracking-[0.2em] text-sm uppercase transition-colors mb-4 font-bold ${product.inStock ? 'bg-black text-white hover:bg-[#C5A059]' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}`}>
              {product.inStock ? 'Add to Collection' : 'Sold Out'}
            </button>

            <button onClick={() => onBuyNow(product)} disabled={!product.inStock} className={`w-full py-4 tracking-[0.2em] text-sm uppercase transition-colors mb-6 border font-bold ${product.inStock ? 'border-black text-black hover:bg-black hover:text-white' : 'border-gray-200 text-gray-400 cursor-not-allowed bg-gray-50'}`}>
              Buy Now
            </button>

            <div className="grid grid-cols-2 gap-4 pt-8 border-t border-gray-200 text-sm text-gray-700">
              <div className="flex items-center"><ShieldCheck className="w-5 h-5 mr-3 text-[#C5A059]" /> Certificate of Authenticity</div>
              <div className="flex items-center"><Truck className="w-5 h-5 mr-3 text-[#C5A059]" /> Secure Crating & Freight</div>
            </div>
          </div>
        </div>

        <div className="mt-32 pt-16 border-t border-gray-200">
          <h3 className="text-3xl font-serif text-black mb-12 text-center uppercase tracking-wider">Customer Reviews</h3>
          {!product.reviews || product.reviews.length === 0 ? (
            <p className="text-center text-gray-500 font-light">No reviews yet for this product.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {product.reviews.map(review => (
                <div key={review.id} className="bg-white p-8 border border-gray-200 shadow-sm">
                  <div className="flex justify-between items-start mb-4">
                    <p className="font-bold text-black uppercase tracking-wider text-sm">{review.user}</p>
                    <div className="flex text-[#C5A059]">{[...Array(5)].map((_, i) => (<Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-current' : ''}`} />))}</div>
                  </div>
                  <p className="text-gray-600 text-sm font-light mb-4 italic">"{review.comment}"</p>
                  {review.image && <div className="mt-2 overflow-hidden border border-gray-200 w-24 h-24"><img src={review.image} alt="Product Review Image" className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" /></div>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const AuthView = ({ isLogin, authForm, onFormChange, onSubmit, onNavigate, onGoogleLogin }: { isLogin: boolean, authForm: any, onFormChange: (v: any) => void, onSubmit: (e: React.FormEvent) => void, onNavigate: (v: string) => void, onGoogleLogin: () => void }) => (
  <div className="min-h-[70vh] flex items-center justify-center px-4 relative animate-fade-in bg-gray-50">
    <div className="w-full max-w-md bg-white p-10 border border-gray-200 shadow-xl">
      <h2 className="text-3xl font-serif text-center text-black mb-8 uppercase tracking-widest">{isLogin ? 'Welcome Back' : 'Wholesale Registration'}</h2>
      <form onSubmit={onSubmit} className="space-y-6">
        {!isLogin && (
          <div>
            <label className="block text-xs tracking-widest uppercase text-gray-500 mb-2 font-bold">Business Name</label>
            <input required type="text" value={authForm.name} onChange={e => onFormChange({...authForm, name: e.target.value})} className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#C5A059] transition-colors" />
          </div>
        )}
        <div>
          <label className="block text-xs tracking-widest uppercase text-gray-500 mb-2 font-bold">Email Address</label>
          <input required type="email" value={authForm.email} onChange={e => onFormChange({...authForm, email: e.target.value})} className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#C5A059] transition-colors" />
        </div>
        <div>
          <label className="block text-xs tracking-widest uppercase text-gray-500 mb-2 font-bold">Password</label>
          <input required type="password" value={authForm.password} onChange={e => onFormChange({...authForm, password: e.target.value})} className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#C5A059] transition-colors" />
        </div>
        <button type="submit" className="w-full bg-black text-white py-4 tracking-[0.2em] text-sm uppercase hover:bg-[#C5A059] transition-colors font-bold mt-4">{isLogin ? 'Sign In' : 'Register'}</button>
      </form>
      
      <div className="relative my-8">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200"></div></div>
        <div className="relative flex justify-center text-xs uppercase tracking-widest"><span className="bg-white px-4 text-gray-400 font-bold">Or continue with</span></div>
      </div>

      <button onClick={onGoogleLogin} className="w-full flex items-center justify-center gap-3 border border-gray-300 bg-white py-4 tracking-[0.2em] text-sm uppercase hover:bg-gray-50 transition-colors font-bold">
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
        Google Account
      </button>

      <div className="mt-8 text-center">
        <button onClick={() => onNavigate(isLogin ? 'SIGNUP' : 'LOGIN')} className="text-sm text-gray-500 hover:text-[#C5A059] transition-colors underline underline-offset-4 uppercase tracking-wider font-bold">
          {isLogin ? "New Wholesaler? Register" : "Already registered? Log in"}
        </button>
      </div>
    </div>
  </div>
);

export const AccountView = ({ currentUser, accountForm, onFormChange, onSubmit, onLogout, onDeleteAccount }: { currentUser: UserType | null, accountForm: any, onFormChange: (v: any) => void, onSubmit: (e: React.FormEvent) => void, onLogout: () => void, onDeleteAccount: () => void }) => {
  if (!currentUser) return null;
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-20 animate-fade-in">
      <h1 className="text-3xl font-serif text-black mb-12 text-center uppercase tracking-wider">Account Settings</h1>
      <div className="bg-white border border-gray-200 shadow-sm p-8 md:p-12">
        <h2 className="text-lg font-serif tracking-widest uppercase mb-8 pb-4 border-b border-gray-200">Account Profile</h2>
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Full Name</label>
              <input required type="text" value={accountForm.name} onChange={e => onFormChange({...accountForm, name: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Email Address</label>
              <input type="email" value={currentUser.email} disabled className="w-full border-b border-gray-200 p-3 text-gray-400 bg-gray-50 cursor-not-allowed" />
              <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest">Email cannot be changed.</p>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Phone Number</label>
            <input type="tel" value={accountForm.phone} onChange={e => onFormChange({...accountForm, phone: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" placeholder="For secure shipping updates" />
          </div>
          <div>
            <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Shipping Address</label>
            <textarea value={accountForm.address} onChange={e => onFormChange({...accountForm, address: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" rows={2} placeholder="Primary business address or warehouse"></textarea>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">City</label>
              <input type="text" value={accountForm.city} onChange={e => onFormChange({...accountForm, city: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" />
            </div>
            <div>
              <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Postal Code</label>
              <input type="text" value={accountForm.pincode} onChange={e => onFormChange({...accountForm, pincode: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] bg-transparent transition-colors" />
            </div>
          </div>
          <div className="pt-8 flex flex-col sm:flex-row gap-4 border-t border-gray-200">
            <button type="submit" className="bg-black text-[#C5A059] px-8 py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-[#C5A059] hover:text-white transition-colors border border-black text-center">Save Changes</button>
            <button type="button" onClick={onLogout} className="border border-gray-300 text-black px-8 py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-gray-100 transition-colors flex items-center justify-center"><LogOut className="w-4 h-4 mr-2" /> Log Out</button>
          </div>
        </form>
        <div className="mt-16 pt-8 border-t border-red-100 bg-red-50/30 p-6 rounded-sm">
          <h3 className="text-sm font-bold tracking-widest uppercase text-red-600 mb-2">Danger Zone</h3>
          <p className="text-xs text-gray-600 mb-4 leading-relaxed">Permanently delete your account and remove all personal data. This action cannot be undone.</p>
          <button type="button" onClick={onDeleteAccount} className="text-red-600 border border-red-200 hover:bg-red-50 px-6 py-3 tracking-[0.2em] text-[10px] uppercase font-bold transition-colors">Delete Account</button>
        </div>
      </div>
    </div>
  );
};

export const SuccessView = ({ onNavigate }: { onNavigate: (v: string) => void }) => (
  <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4 animate-fade-in bg-white">
    <Crown className="w-24 h-24 text-[#C5A059] mb-8" />
    <h1 className="text-4xl md:text-5xl font-serif text-black mb-6 uppercase tracking-widest">Order Confirmed</h1>
    <p className="text-gray-600 mb-10 max-w-lg text-lg font-light leading-relaxed">Thank you for choosing Akaay Enterprise. Your wholesale order is currently being prepared for dispatch and freight delivery.</p>
    <div className="flex flex-col sm:flex-row gap-6">
      <button onClick={() => onNavigate('MY_ORDERS')} className="bg-black text-white px-10 py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-[#C5A059] transition-colors">View Order Details</button>
      <button onClick={() => onNavigate('HOME')} className="border border-black text-black px-10 py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-black hover:text-white transition-colors">Return to Shop</button>
    </div>
  </div>
);
