import React from 'react';
import { Package, Star, CheckCircle2, X, AlertCircle } from 'lucide-react';
import { Order, User } from '../types';

interface MyOrdersProps {
  currentUser: User | null;
  ordersDb: Order[];
  onNavigate: (view: string) => void;
  formatPrice: (price: number) => string;
  onSetReviewingItem: (item: any) => void;
  onSetCancellingOrder: (order: Order) => void;
  onSetReturningOrder: (order: Order) => void;
}

export default function MyOrders({ 
  currentUser, ordersDb, onNavigate, formatPrice, onSetReviewingItem, onSetCancellingOrder, onSetReturningOrder 
}: MyOrdersProps) {
  if (!currentUser) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
      <Package className="w-16 h-16 text-gray-300 mb-6" />
      <h2 className="text-2xl font-serif mb-4 text-black uppercase tracking-widest">Wholesale Login Required</h2>
      <button onClick={() => onNavigate('LOGIN')} className="bg-black text-white px-8 py-4 tracking-[0.2em] text-sm uppercase hover:bg-[#C5A059] font-bold">Log In</button>
    </div>
  );

  const myOrders = ordersDb.filter(order => order.customer?.email === currentUser.email);

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 md:py-20 animate-fade-in">
      <h1 className="text-3xl font-serif text-black mb-12 text-center uppercase tracking-wider">My Orders</h1>
      {myOrders.length === 0 ? (
        <div className="text-center py-24 bg-white border border-gray-200 shadow-sm">
          <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 font-serif italic text-lg mb-8">No order history found. Start your distribution today.</p>
          <button onClick={() => onNavigate('HOME')} className="bg-black text-white px-8 py-4 tracking-[0.2em] text-sm uppercase hover:bg-[#C5A059] font-bold">Browse Products</button>
        </div>
      ) : (
        <div className="space-y-8">
          {myOrders.map((order) => (
            <div key={order.orderId} className="bg-white border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-200 bg-gray-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div><p className="text-xs tracking-widest uppercase text-gray-500 mb-1 font-bold">Date Acquired</p><p className="text-sm font-medium">{order.date}</p></div>
                <div><p className="text-xs tracking-widest uppercase text-gray-500 mb-1 font-bold">Total Investment</p><p className="text-sm font-medium">{formatPrice(order.total)}</p></div>
                <div>
                  <p className="text-xs tracking-widest uppercase text-gray-500 mb-1 font-bold">Status</p>
                  <span className={`text-[10px] font-bold tracking-widest uppercase px-3 py-1 border ${
                    order.status === 'Cancelled' ? 'bg-red-50 text-red-600 border-red-200' : 
                    order.status.includes('Return') ? 'bg-orange-50 text-orange-600 border-orange-200' :
                    order.status === 'Delivered' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-black text-[#C5A059] border-black'
                  }`}>{order.status}</span>
                </div>
                <div className="text-right"><p className="text-[10px] font-mono text-gray-500 bg-white border border-gray-200 px-2 py-1">{order.orderId}</p></div>
              </div>
              
              <div className="p-8">
                <div className="space-y-6">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-6">
                      {item.mainMediaType === 'video' ? <video src={item.image} autoPlay muted loop playsInline className="w-20 h-24 object-cover border border-gray-200" /> : <img src={item.image} alt={item.name} className="w-20 h-24 object-cover border border-gray-200" />}
                      <div className="flex-1">
                        <h4 className="text-base font-serif font-bold text-black uppercase">{item.name}</h4>
                        <p className="text-xs text-gray-500 tracking-widest uppercase mt-1">Quantity: {item.quantity}</p>
                        {order.status === 'Delivered' && !item.reviewed && (
                          <button onClick={() => onSetReviewingItem({ productId: item.id, orderId: order.orderId, name: item.name })} className="text-[10px] uppercase tracking-widest text-[#C5A059] font-bold mt-3 hover:text-black transition-colors inline-flex items-center"><Star className="w-3 h-3 mr-1 fill-current" /> Write a Review</button>
                        )}
                        {item.reviewed && <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold mt-3 inline-flex items-center"><CheckCircle2 className="w-3 h-3 mr-1" /> Reviewed</p>}
                      </div>
                      <p className="text-base font-bold text-black">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                  ))}
                </div>
                
                {order.status !== 'Cancelled' && order.status !== 'Delivered' && !order.status.includes('Return') && (
                  <div className="mt-8 pt-6 border-t border-gray-200 flex justify-end">
                    <button onClick={() => onSetCancellingOrder(order)} className="flex items-center text-[10px] tracking-widest uppercase font-bold text-gray-500 hover:text-red-600 px-4 py-2 transition-colors border border-gray-200 hover:border-red-200"><X className="w-3 h-3 mr-2" /> Cancel Order</button>
                  </div>
                )}

                {order.status === 'Delivered' && (!order.deliveryDate || (new Date().getTime() - order.deliveryDate) <= 5 * 24 * 60 * 60 * 1000) && (
                  <div className="mt-8 pt-6 border-t border-gray-200 flex justify-end">
                    <button onClick={() => onSetReturningOrder(order)} className="flex items-center text-[10px] tracking-widest uppercase font-bold text-gray-500 hover:text-orange-600 px-4 py-2 transition-colors border border-gray-200 hover:border-orange-200"><AlertCircle className="w-3 h-3 mr-2" /> Request Return</button>
                  </div>
                )}
                
                {order.status === 'Cancelled' && order.cancelReason && <div className="mt-6 p-4 bg-gray-50 border border-gray-200"><p className="text-[10px] tracking-widest uppercase text-red-600 font-bold mb-1">Reason for Cancellation</p><p className="text-xs italic text-gray-600">"{order.cancelReason}"</p></div>}
                {order.status.includes('Return') && order.returnReason && <div className="mt-6 p-4 bg-gray-50 border border-gray-200"><p className="text-[10px] tracking-widest uppercase text-orange-600 font-bold mb-1">Return Reason</p><p className="text-xs italic text-gray-600">"{order.returnReason}"</p></div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
