import React from 'react';
import { 
  LayoutDashboard, PlusCircle, Settings, LineChart, ImageIcon, Lock, LogOut, Menu, X, Crown, Package, Users, Search, Tag, Trash2, Image as ImageIconLucide, CreditCard, StickyNote
} from 'lucide-react';
import { Product, Order, User, ORDER_STATUSES } from '../types';

interface AdminPanelProps {
  adminTab: string;
  setAdminTab: (tab: string) => void;
  isAdminSidebarOpen: boolean;
  setIsAdminSidebarOpen: (open: boolean) => void;
  ordersDb: Order[];
  productsDb: Product[];
  usersDb: User[];
  manualRevenues: any[];
  revenueSearchQuery: string;
  setRevenueSearchQuery: (q: string) => void;
  manualRevenueSearchQuery: string;
  setManualRevenueSearchQuery: (q: string) => void;
  revenueForm: any;
  setRevenueForm: (f: any) => void;
  adminSettingsForm: any;
  setAdminSettingsForm: (f: any) => void;
  newProductForm: any;
  setNewProductForm: (f: any) => void;
  onLogout: () => void;
  onAddManualRevenue: (e: React.FormEvent) => void;
  onDeleteManualRevenue: (id: string) => void;
  onAddProduct: (e: React.FormEvent) => void;
  onUpdateStock: (id: string | number, qty: string) => void;
  onDeleteProduct: (id: string | number) => void;
  onUpdateProductImage: (id: string | number, e: React.ChangeEvent<HTMLInputElement>) => void;
  onOpenPriceEdit: (product: Product) => void;
  onPasswordChange: (e: React.FormEvent) => void;
  onRazorpayUpdate: (e: React.FormEvent) => void;
  onBannerUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveBanner: () => void;
  onOrderStatusChange: (orderId: string, status: string) => void;
  bannerImage: string | null;
  formatPrice: (price: number) => string;
  onMediaUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveMedia: (id: number) => void;
  notesDb: any[];
  onAddNote: (e: React.FormEvent, text: string) => void;
  onDeleteNote: (id: string) => void;
  onUpdateLegalAndBanner: (e: React.FormEvent, newSettings: any) => void;
  topBannerText: string;
  privacyPolicy: string;
  termsOfService: string;
}

export default function AdminPanel(props: AdminPanelProps) {
  const { 
    adminTab, setAdminTab, isAdminSidebarOpen, setIsAdminSidebarOpen, ordersDb, productsDb, usersDb, 
    manualRevenues, revenueSearchQuery, setRevenueSearchQuery, manualRevenueSearchQuery, setManualRevenueSearchQuery,
    revenueForm, setRevenueForm, adminSettingsForm, setAdminSettingsForm, newProductForm, setNewProductForm,
    onLogout, onAddManualRevenue, onDeleteManualRevenue, onAddProduct, onUpdateStock, onDeleteProduct,
    onUpdateProductImage, onOpenPriceEdit, onPasswordChange, onRazorpayUpdate, onBannerUpload, onRemoveBanner,
    onOrderStatusChange, bannerImage, formatPrice, onMediaUpload, onRemoveMedia,
    onUpdateLegalAndBanner, topBannerText, privacyPolicy, termsOfService,
    notesDb, onAddNote, onDeleteNote
  } = props;

  const [legalForm, setLegalForm] = React.useState({
    topBannerText: topBannerText || '',
    privacyPolicy: privacyPolicy || '',
    termsOfService: termsOfService || ''
  });

  const [noteText, setNoteText] = React.useState('');

  React.useEffect(() => {
    setLegalForm({
      topBannerText: topBannerText || '',
      privacyPolicy: privacyPolicy || '',
      termsOfService: termsOfService || ''
    });
  }, [topBannerText, privacyPolicy, termsOfService]);

  const validOrders = ordersDb.filter(o => o.status !== 'Cancelled' && o.status !== 'Returned');
  const revenueHistoryMap: Record<string, any> = {};
  validOrders.forEach(order => {
    const dateObj = order.createdAt ? new Date(order.createdAt) : new Date(order.date);
    if (isNaN(dateObj.getTime())) return;
    const month = dateObj.toLocaleString('default', { month: 'long' });
    const year = dateObj.getFullYear();
    const key = `${month} ${year}`;
    if (!revenueHistoryMap[key]) revenueHistoryMap[key] = { key, month, year, revenue: 0, orderCount: 0, rawDate: new Date(year, dateObj.getMonth(), 1) };
    revenueHistoryMap[key].revenue += order.total;
    revenueHistoryMap[key].orderCount += 1;
  });

  const revenueHistory = Object.values(revenueHistoryMap).sort((a, b) => b.rawDate - a.rawDate);
  const currentMonthKey = `${new Date().toLocaleString('default', { month: 'long' })} ${new Date().getFullYear()}`;
  const currentMonthRevenue = revenueHistoryMap[currentMonthKey]?.revenue || 0;
  const filteredRevenueHistory = revenueHistory.filter(h => h.key.toLowerCase().includes(revenueSearchQuery.toLowerCase()));
  const filteredManualRevenues = manualRevenues.filter(r => `${r.month} ${r.year}`.toLowerCase().includes(manualRevenueSearchQuery.toLowerCase()));

  return (
    <div className="min-h-screen bg-gray-100 flex animate-fade-in overflow-hidden relative font-sans">
      {isAdminSidebarOpen && <div className="fixed inset-0 bg-black/60 z-40 md:hidden backdrop-blur-sm" onClick={() => setIsAdminSidebarOpen(false)} />}

      <div className={`bg-black text-white h-screen flex flex-col fixed left-0 top-0 z-50 transition-transform duration-300 w-64 border-r border-[#333] ${isAdminSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-8 bg-[#0a0a0a] flex items-center justify-between border-b border-[#333]">
          <div className="flex items-center space-x-3"><Crown className="w-6 h-6 text-[#C5A059]" /><span className="font-serif font-bold tracking-widest uppercase text-sm">Akaay Enterprise Admin</span></div>
          <button onClick={() => setIsAdminSidebarOpen(false)} className="md:hidden text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <nav className="flex-1 px-4 py-8 space-y-2">
          {[ 
            { id: 'DASHBOARD', icon: LayoutDashboard, label: 'Dashboard' }, 
            { id: 'ADD_PRODUCT', icon: PlusCircle, label: 'Add Product' }, 
            { id: 'MANAGE_PRODUCTS', icon: Settings, label: 'Inventory' }, 
            { id: 'MANAGE_REVENUE', icon: LineChart, label: 'Manage Revenue' }, 
            { id: 'MANAGE_BANNER', icon: ImageIcon, label: 'Legal & Banner' }, 
            { id: 'NOTES', icon: StickyNote, label: 'Admin Notes' },
            { id: 'SETTINGS', icon: Lock, label: 'Settings' } 
          ].map(tab => (
            <button key={tab.id} onClick={() => { setAdminTab(tab.id); if(window.innerWidth < 768) setIsAdminSidebarOpen(false); }} className={`w-full flex items-center space-x-3 px-4 py-4 uppercase tracking-widest text-xs font-bold transition-colors ${adminTab === tab.id ? 'bg-[#111] text-[#C5A059] border-l-2 border-[#C5A059]' : 'text-gray-400 hover:bg-[#111] hover:text-white border-l-2 border-transparent'}`}>
              <tab.icon className="w-4 h-4" /> <span>{tab.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-6 border-t border-[#333] bg-[#0a0a0a]">
          <button onClick={onLogout} className="w-full flex items-center justify-center space-x-2 bg-[#222] text-white px-4 py-3 uppercase tracking-widest text-xs font-bold hover:bg-red-900 transition-colors border border-[#333]"><LogOut className="w-4 h-4" /> <span>Logout Admin</span></button>
        </div>
      </div>

      <div className={`flex-1 transition-all duration-300 h-screen overflow-y-auto ${isAdminSidebarOpen ? 'md:ml-64' : 'ml-0'}`}>
        <div className="bg-white p-6 flex items-center shadow-sm mb-8 sticky top-0 z-30 border-b border-gray-200">
          <button onClick={() => setIsAdminSidebarOpen(!isAdminSidebarOpen)} className="p-2 mr-4 bg-gray-50 border border-gray-200 hover:bg-gray-100 text-black transition-colors focus:outline-none" title="Toggle Sidebar"><Menu className="w-5 h-5" /></button>
          <h2 className="font-serif font-bold text-black uppercase tracking-widest text-lg">
            {adminTab === 'DASHBOARD' && 'Wholesale Overview'}
            {adminTab === 'ADD_PRODUCT' && 'Add New Product'}
            {adminTab === 'MANAGE_PRODUCTS' && 'Manage Inventory'}
            {adminTab === 'MANAGE_REVENUE' && 'Manage Revenue'}
            {adminTab === 'MANAGE_BANNER' && 'Legal & Store Appearance'}
            {adminTab === 'NOTES' && 'Admin Notes'}
            {adminTab === 'SETTINGS' && 'System Settings'}
          </h2>
        </div>

        <div className="px-8 pb-12">
          {adminTab === 'DASHBOARD' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
                <div className="bg-white p-8 border border-gray-200 shadow-sm flex items-center justify-between"><div><p className="text-gray-500 text-xs tracking-widest uppercase font-bold mb-2">Total Orders</p><p className="text-4xl font-serif text-black">{ordersDb.length}</p></div><div className="p-4 bg-gray-50 border border-gray-100"><Package className="w-8 h-8 text-[#C5A059]" /></div></div>
                <div className="bg-white p-8 border border-gray-200 shadow-sm flex items-center justify-between"><div><p className="text-gray-500 text-xs tracking-widest uppercase font-bold mb-2">This Month's Revenue</p><p className="text-3xl font-serif text-black">{formatPrice(currentMonthRevenue)}</p></div><div className="p-4 bg-gray-50 border border-gray-100"><span className="text-2xl font-serif font-bold text-[#C5A059]">₹</span></div></div>
                <div className="bg-white p-8 border border-gray-200 shadow-sm flex items-center justify-between"><div><p className="text-gray-500 text-xs tracking-widest uppercase font-bold mb-2">Wholesalers</p><p className="text-4xl font-serif text-black">{usersDb.length}</p></div><div className="p-4 bg-gray-50 border border-gray-100"><Users className="w-8 h-8 text-[#C5A059]" /></div></div>
              </div>
              
              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden mb-10">
                <div className="px-8 py-6 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center bg-gray-50 gap-4">
                  <h3 className="font-serif font-bold text-black text-xl uppercase tracking-wider">Revenue History</h3>
                  <div className="relative w-full md:w-auto">
                    <Search className="w-4 h-4 absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input type="text" placeholder="Search Month/Year..." value={revenueSearchQuery} onChange={(e) => setRevenueSearchQuery(e.target.value)} className="w-full md:w-64 pl-12 pr-4 py-3 border border-gray-300 text-xs tracking-widest uppercase font-bold focus:outline-none focus:border-black transition-colors" />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead><tr className="bg-white text-gray-500 text-[10px] uppercase tracking-widest border-b border-gray-200"><th className="p-6 font-bold">Time Period</th><th className="p-6 font-bold text-center">Completed Orders</th><th className="p-6 font-bold text-right">Revenue Generated</th></tr></thead>
                    <tbody className="divide-y divide-gray-100 text-sm">
                      {filteredRevenueHistory.length === 0 ? (
                        <tr><td colSpan={3} className="p-12 text-center text-gray-500 font-serif italic text-lg">No revenue data found.</td></tr>
                      ) : (
                        filteredRevenueHistory.map((hist, idx) => (
                          <tr key={idx} className="hover:bg-gray-50 transition-colors"><td className="p-6 font-bold text-black uppercase tracking-wider text-xs">{hist.month} <span className="text-gray-500">{hist.year}</span></td><td className="p-6 text-center text-gray-600 font-medium">{hist.orderCount}</td><td className="p-6 text-right font-serif text-lg font-bold text-[#C5A059]">{formatPrice(hist.revenue)}</td></tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-8 py-6 border-b border-gray-200 flex justify-between items-center bg-gray-50"><h3 className="font-serif font-bold text-black text-xl uppercase tracking-wider">Recent Orders</h3></div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead><tr className="bg-white text-gray-500 text-[10px] uppercase tracking-widest border-b border-gray-200"><th className="p-6 font-bold">Order ID / Date</th><th className="p-6 font-bold">Wholesaler Details</th><th className="p-6 font-bold">Products Acquired</th><th className="p-6 font-bold">Status / Payment</th><th className="p-6 font-bold text-right">Total Amount</th></tr></thead>
                    <tbody className="divide-y divide-gray-100 text-sm">
                      {ordersDb.length === 0 ? (
                        <tr><td colSpan={5} className="p-12 text-center text-gray-500 font-serif italic text-lg">No orders recorded yet.</td></tr>
                      ) : (
                        ordersDb.map((order, idx) => (
                          <tr key={idx} className="hover:bg-gray-50 transition-colors">
                            <td className="p-6 align-top"><span className="font-mono font-bold text-black">{order.orderId}</span><br/><span className="text-xs text-gray-500 mt-2 block">{order.date}</span></td>
                            <td className="p-6 align-top"><p className="font-bold text-black uppercase tracking-wider text-xs mb-1">{order.customer?.name}</p><p className="text-gray-500 text-xs">{order.customer?.email}</p><p className="text-gray-500 text-xs mt-1">Ph: {order.shipping?.phone}</p></td>
                            <td className="p-6 align-top">
                              <ul className="text-xs space-y-2 text-gray-800 max-w-[250px]">
                                {order.items.map((item, i) => (<li key={i} className="flex justify-between border-b border-gray-100 pb-2 last:border-0 font-medium"><span className="truncate pr-2 uppercase">{item.name}</span><span className="font-bold text-[#C5A059]">x{item.quantity}</span></li>))}
                              </ul>
                            </td>
                            <td className="p-6 align-top">
                              <div className="flex flex-col gap-3">
                                {order.status === 'Cancelled' || order.status === 'Returned' ? (
                                  <span className={`w-fit px-3 py-1 text-[10px] font-bold tracking-widest uppercase border ${order.status === 'Cancelled' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-gray-100 text-gray-700 border-gray-300'}`}>{order.status}</span>
                                ) : (
                                  <select value={order.status} onChange={(e) => onOrderStatusChange(order.orderId, e.target.value)} className={`max-w-[160px] px-3 py-2 text-[10px] font-bold tracking-widest uppercase outline-none border cursor-pointer ${order.status === 'Delivered' ? 'bg-green-50 text-green-700 border-green-200' : order.status.includes('Return') ? 'bg-orange-50 text-orange-700 border-orange-200' : 'bg-white text-black border-black focus:ring-1 focus:ring-black'}`}>
                                    {ORDER_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                                  </select>
                                )}
                                {order.status === 'Cancelled' && order.cancelReason && <span className="text-[10px] text-red-600 italic mt-1 bg-red-50 p-2 border border-red-100">Cancel: {order.cancelReason}</span>}
                                {order.status.includes('Return') && order.returnReason && <span className="text-[10px] text-orange-600 italic mt-1 bg-orange-50 p-2 border border-orange-100">Return: {order.returnReason}</span>}
                                <span className={`w-fit px-3 py-1 text-[10px] font-bold tracking-widest uppercase border ${order.paymentMethod === 'COD' ? 'bg-gray-50 text-gray-700 border-gray-300' : 'bg-[#C5A059]/10 text-[#9c7b3e] border-[#C5A059]'}`}>{order.paymentMethod}</span>
                                {order.transactionId && <span className="text-[9px] text-gray-400 font-mono mt-1 break-all">TXN: {order.transactionId}</span>}
                              </div>
                            </td>
                            <td className="p-6 align-top text-right font-serif text-lg font-bold text-black">{formatPrice(order.total)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {adminTab === 'ADD_PRODUCT' && (
            <div className="bg-white shadow-sm border border-gray-200 max-w-3xl mx-auto">
              <div className="px-8 py-6 border-b border-gray-200 bg-gray-50"><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Catalog New Product</h3></div>
              <form onSubmit={onAddProduct} className="p-8 space-y-8">
                <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Product Title</label><input required type="text" value={newProductForm.name} onChange={e => setNewProductForm({...newProductForm, name: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-transparent text-lg font-serif" placeholder="e.g. Premium Cola Case" /></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Wholesale Price (₹)</label><input required type="number" min="0" value={newProductForm.price} onChange={e => setNewProductForm({...newProductForm, price: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-transparent font-mono text-lg" placeholder="e.g. 1500" /></div>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Quantity</label><input required type="number" min="1" value={newProductForm.stockQuantity} onChange={e => setNewProductForm({...newProductForm, stockQuantity: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-transparent font-mono text-lg" placeholder="10" /></div>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Category</label><select value={newProductForm.category} onChange={e => setNewProductForm({...newProductForm, category: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-white font-medium"><option value="Beverages">Beverages</option><option value="Chocolates">Chocolates</option><option value="Snacks">Snacks</option><option value="Bulk Add-ons">Bulk Add-ons</option></select></div>
                </div>
                <div>
                  <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-4">Product Image</label>
                  <div className="flex flex-wrap gap-4 items-start p-4 bg-gray-50 border border-gray-200">
                    {newProductForm.media.map((item: any) => (
                      <div key={item.id} className="relative w-32 h-32 border border-gray-300 bg-white overflow-hidden group shadow-sm">
                        {item.type === 'video' ? <video src={item.url} className="w-full h-full object-cover" /> : <img src={item.url} alt="Preview" className="w-full h-full object-cover" />}
                        {item.type === 'video' && <div className="absolute bottom-1 left-1 bg-black/80 text-white text-[8px] px-2 py-1 uppercase tracking-widest font-bold">Video</div>}
                        <button type="button" onClick={() => onRemoveMedia(item.id)} className="absolute top-2 right-2 bg-white p-1.5 shadow-md hover:bg-red-600 hover:text-white transition-colors opacity-0 group-hover:opacity-100"><X className="w-4 h-4" /></button>
                      </div>
                    ))}
                    <label className="w-32 h-32 flex flex-col items-center justify-center border-2 border-dashed border-gray-400 bg-white cursor-pointer hover:bg-gray-100 transition-all shrink-0"><PlusCircle className="w-8 h-8 text-gray-400 mb-2" /><span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center leading-tight">Add<br/>Media</span><input type="file" accept="image/*,video/*" multiple onChange={onMediaUpload} className="hidden" /></label>
                  </div>
                </div>
                <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Product Description</label><textarea required value={newProductForm.description} onChange={e => setNewProductForm({...newProductForm, description: e.target.value})} className="w-full border border-gray-300 p-4 focus:outline-none focus:border-black transition-colors bg-gray-50 resize-y" rows={5} placeholder="Detail the bulk specifications..."></textarea></div>
                <div className="pt-6 border-t border-gray-200"><button type="submit" className="w-full bg-black text-white font-bold py-5 uppercase tracking-[0.2em] text-sm hover:bg-[#C5A059] transition-colors flex items-center justify-center space-x-3"><PlusCircle className="w-5 h-5" /> <span>Add to Inventory</span></button></div>
              </form>
            </div>
          )}

          {adminTab === 'MANAGE_PRODUCTS' && (
            <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-8 py-6 border-b border-gray-200 flex justify-between items-center bg-gray-50"><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Warehouse Inventory</h3><span className="bg-black text-[#C5A059] text-[10px] font-bold uppercase tracking-widest px-4 py-2">{productsDb.length} Products</span></div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead><tr className="bg-white text-gray-500 text-[10px] uppercase tracking-widest border-b border-gray-200"><th className="p-6 font-bold">Image</th><th className="p-6 font-bold">Product Details</th><th className="p-6 font-bold">Stock Quantity</th><th className="p-6 font-bold text-right">Actions</th></tr></thead>
                  <tbody className="divide-y divide-gray-100 text-sm">
                    {productsDb.map((product) => (
                      <tr key={product.id} className={`hover:bg-gray-50 transition-colors ${!product.inStock ? 'bg-gray-50/80' : ''}`}>
                        <td className="p-6 w-32">
                          <div className="relative group w-20 h-24 border border-gray-200 overflow-hidden bg-gray-100 shadow-sm">
                            {product.mainMediaType === 'video' ? <video src={product.image} autoPlay muted loop playsInline className="w-full h-full object-cover" /> : <img src={product.image} className="w-full h-full object-cover" alt={product.name} />}
                            <label className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white"><ImageIconLucide className="w-5 h-5 mb-1 text-[#C5A059]" /><span className="text-[8px] uppercase tracking-widest font-bold">Change</span><input type="file" accept="image/*,video/*" onChange={(e) => onUpdateProductImage(product.id, e)} className="hidden" /></label>
                          </div>
                        </td>
                        <td className="p-6">
                          <p className="font-serif font-bold text-black uppercase tracking-wide text-base">{product.name}</p>
                          <p className="text-[10px] text-gray-500 mt-2 uppercase tracking-widest font-bold">{product.category}</p>
                          {product.originalPrice ? (
                            <div className="mt-2"><p className="font-medium text-red-600 text-lg flex items-center gap-2">{formatPrice(product.price)} <span className="text-xs text-gray-400 line-through">{formatPrice(product.originalPrice)}</span></p><p className="text-[9px] text-[#C5A059] uppercase tracking-widest mt-1">Sale ends: {product.saleEndDate ? new Date(product.saleEndDate).toLocaleString() : 'N/A'}</p></div>
                          ) : (
                            <p className="font-medium mt-2 text-gray-800 text-lg">{formatPrice(product.price)}</p>
                          )}
                        </td>
                        <td className="p-6">
                          <div className="flex flex-col items-start gap-2">
                            <input type="number" min="0" value={product.stockQuantity} onChange={(e) => onUpdateStock(product.id, e.target.value)} className={`w-20 px-3 py-2 text-sm font-mono border focus:outline-none focus:border-black transition-colors ${product.inStock ? 'border-gray-300 bg-white' : 'border-red-300 bg-red-50 text-red-600'}`} />
                            <span className={`text-[9px] uppercase tracking-widest font-bold ${product.inStock ? 'text-green-600' : 'text-red-500'}`}>{product.inStock ? 'Available' : 'Sold Out'}</span>
                          </div>
                        </td>
                        <td className="p-6 text-right">
                          <button onClick={() => onOpenPriceEdit(product)} className="p-3 text-gray-400 border border-transparent hover:border-black hover:text-black hover:bg-gray-100 transition-all inline-flex items-center gap-1 mr-2" title="Update Pricing"><Tag className="w-5 h-5" /></button>
                          <button onClick={() => onDeleteProduct(product.id)} className="p-3 text-gray-400 border border-transparent hover:border-red-200 hover:text-red-600 hover:bg-red-50 transition-all inline-flex items-center gap-1" title="Delete Product"><Trash2 className="w-5 h-5" /></button>
                        </td>
                      </tr>
                    ))}
                    {productsDb.length === 0 && <tr><td colSpan={4} className="text-center p-12 text-gray-500 font-serif italic text-lg">No products found in inventory.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'MANAGE_REVENUE' && (
            <div className="bg-white shadow-sm border border-gray-200 max-w-4xl mx-auto overflow-hidden animate-fade-in">
              <div className="px-8 py-6 border-b border-gray-200 bg-gray-50"><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Record Monthly Revenue</h3></div>
              <form onSubmit={onAddManualRevenue} className="p-8 space-y-8 border-b border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Month</label><select value={revenueForm.month} onChange={e => setRevenueForm({...revenueForm, month: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-white font-medium">{['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => <option key={m} value={m}>{m}</option>)}</select></div>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Year</label><input required type="number" min="2000" max="2100" value={revenueForm.year} onChange={e => setRevenueForm({...revenueForm, year: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-transparent font-mono text-lg" /></div>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Total Revenue (₹)</label><input required type="number" min="0" value={revenueForm.amount} onChange={e => setRevenueForm({...revenueForm, amount: e.target.value})} className="w-full border-b border-gray-300 p-3 focus:outline-none focus:border-[#C5A059] transition-colors bg-transparent font-mono text-lg" placeholder="e.g. 500000" /></div>
                </div>
                <button type="submit" className="bg-black text-[#C5A059] font-bold py-4 px-8 uppercase tracking-[0.2em] text-xs hover:bg-[#C5A059] hover:text-white transition-colors inline-flex items-center gap-2 mt-4 border border-black"><PlusCircle className="w-4 h-4" /> Save Revenue Record</button>
              </form>
              
              <div className="bg-gray-50 p-8">
                <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                  <h4 className="font-serif font-bold text-lg uppercase tracking-wider text-black">Revenue Ledger</h4>
                  <div className="relative w-full md:w-auto"><Search className="w-4 h-4 absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search Month/Year..." value={manualRevenueSearchQuery} onChange={(e) => setManualRevenueSearchQuery(e.target.value)} className="w-full md:w-64 pl-12 pr-4 py-3 border border-gray-300 text-xs tracking-widest uppercase font-bold focus:outline-none focus:border-black transition-colors bg-white" /></div>
                </div>
                {filteredManualRevenues.length === 0 ? (
                  <div className="text-center p-8 bg-white border border-gray-200"><p className="text-gray-500 text-sm font-medium italic">{manualRevenues.length === 0 ? "No manual revenue records added yet." : "No records found matching your search."}</p></div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse bg-white border border-gray-200">
                      <thead><tr className="bg-gray-100 text-gray-500 text-[10px] uppercase tracking-widest border-b border-gray-200"><th className="p-5 font-bold">Month / Year</th><th className="p-5 font-bold text-right">Revenue</th><th className="p-5 font-bold text-center">Action</th></tr></thead>
                      <tbody className="divide-y divide-gray-100 text-sm">
                        {filteredManualRevenues.map((record: any) => (
                          <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                            <td className="p-5 font-bold text-black uppercase tracking-wider text-xs">{record.month} {record.year}<div className="text-[9px] text-gray-400 mt-1 font-normal normal-case">Added: {record.dateAdded}</div></td>
                            <td className="p-5 text-right font-serif text-lg font-bold text-[#C5A059]">{formatPrice(record.amount)}</td>
                            <td className="p-5 text-center"><button onClick={() => onDeleteManualRevenue(record.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors rounded-full" title="Delete Record"><Trash2 className="w-4 h-4 mx-auto" /></button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {adminTab === 'MANAGE_BANNER' && (
            <div className="max-w-4xl mx-auto space-y-10 animate-fade-in">
              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-8 py-6 border-b border-gray-200 bg-gray-50 flex items-center"><ImageIconLucide className="w-5 h-5 mr-4 text-black" /><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Store Appearance & Legal</h3></div>
                
                <form onSubmit={(e) => onUpdateLegalAndBanner(e, legalForm)} className="p-8 space-y-8">
                  <div>
                    <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Top Announcement Banner Text</label>
                    <input 
                      type="text" 
                      value={legalForm.topBannerText} 
                      onChange={e => setLegalForm({...legalForm, topBannerText: e.target.value})} 
                      className="w-full border border-gray-300 p-4 focus:outline-none focus:border-black transition-colors bg-gray-50" 
                      placeholder="e.g. Complimentary Shipping on orders over ₹1,000" 
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Privacy Policy Content</label>
                    <textarea 
                      value={legalForm.privacyPolicy} 
                      onChange={e => setLegalForm({...legalForm, privacyPolicy: e.target.value})} 
                      className="w-full border border-gray-300 p-4 focus:outline-none focus:border-black transition-colors bg-gray-50 resize-y" 
                      rows={8} 
                      placeholder="Enter the full privacy policy text here..."
                    ></textarea>
                  </div>

                  <div>
                    <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Terms of Service Content</label>
                    <textarea 
                      value={legalForm.termsOfService} 
                      onChange={e => setLegalForm({...legalForm, termsOfService: e.target.value})} 
                      className="w-full border border-gray-300 p-4 focus:outline-none focus:border-black transition-colors bg-gray-50 resize-y" 
                      rows={8} 
                      placeholder="Enter the full terms of service text here..."
                    ></textarea>
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <button type="submit" className="bg-black text-[#C5A059] border border-black px-10 py-4 font-bold uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-colors">Save Legal & Banner Text</button>
                  </div>
                </form>

                <div className="p-8 border-t border-gray-200 space-y-6 bg-gray-50">
                  <h4 className="font-serif font-bold text-lg uppercase tracking-wider text-black">Hero Image Banner</h4>
                  <p className="text-sm text-gray-600 mb-6 font-medium leading-relaxed">Update the main hero banner displayed on the wholesale shop home page.</p>
                  <div className="flex flex-col gap-6">
                    {bannerImage && <div className="relative w-full h-48 bg-black border border-gray-200 overflow-hidden mb-2"><img src={bannerImage} className="w-full h-full object-cover opacity-60 mix-blend-luminosity" alt="Current Banner" /></div>}
                    <div className="flex flex-wrap gap-4">
                      <label className="bg-black text-[#C5A059] border border-black px-8 py-3 font-bold uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-colors cursor-pointer text-center inline-block">
                        Upload New Banner <input type="file" accept="image/*" onChange={onBannerUpload} className="hidden" />
                      </label>
                      {bannerImage && <button onClick={onRemoveBanner} className="border border-red-200 text-red-600 px-8 py-3 font-bold uppercase tracking-[0.2em] text-xs hover:bg-red-50 transition-colors">Remove Banner</button>}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {adminTab === 'NOTES' && (
            <div className="max-w-4xl mx-auto space-y-10 animate-fade-in">
              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-8 py-6 border-b border-gray-200 bg-gray-50 flex items-center">
                  <StickyNote className="w-5 h-5 mr-4 text-black" />
                  <h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Website Notes</h3>
                </div>
                <form 
                  onSubmit={(e) => { 
                    onAddNote(e, noteText); 
                    if(noteText.trim()) setNoteText(''); 
                  }} 
                  className="p-8 space-y-6"
                >
                  <div>
                    <label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">New Note</label>
                    <textarea 
                      required
                      value={noteText}
                      onChange={e => setNoteText(e.target.value)}
                      className="w-full border border-gray-300 p-4 focus:outline-none focus:border-black transition-colors bg-gray-50 resize-y"
                      rows={4}
                      placeholder="Write your notes here..."
                    ></textarea>
                  </div>
                  <div>
                    <button type="submit" className="bg-black text-[#C5A059] px-8 py-4 font-bold uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-colors border border-black inline-flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Save Note
                    </button>
                  </div>
                </form>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {notesDb.length === 0 ? (
                  <div className="col-span-1 md:col-span-2 text-center p-12 bg-white border border-gray-200">
                    <p className="text-gray-500 font-serif italic text-lg">No notes added yet.</p>
                  </div>
                ) : (
                  notesDb.map(note => (
                    <div key={note.id} className="bg-white p-6 border border-gray-200 shadow-sm relative group">
                      <p className="text-[9px] uppercase tracking-widest text-gray-400 mb-3">{note.date}</p>
                      <p className="text-sm text-gray-800 whitespace-pre-wrap">{note.text}</p>
                      <button 
                        type="button"
                        onClick={() => onDeleteNote(note.id)} 
                        className="absolute top-4 right-4 p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 transition-colors rounded-full opacity-0 group-hover:opacity-100"
                        title="Delete Note"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {adminTab === 'SETTINGS' && (
            <div className="max-w-4xl mx-auto space-y-10 animate-fade-in">
              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-8 py-6 border-b border-gray-200 bg-gray-50 flex items-center"><Lock className="w-5 h-5 mr-4 text-black" /><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Admin Security</h3></div>
                <form onSubmit={onPasswordChange} className="p-8 space-y-6">
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Current Password</label><input required type="password" value={adminSettingsForm.currentPassword} onChange={e => setAdminSettingsForm({...adminSettingsForm, currentPassword: e.target.value})} className="w-full border-b border-gray-300 p-3 outline-none focus:border-black transition-colors" /></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">New Password</label><input required type="password" value={adminSettingsForm.newPassword} onChange={e => setAdminSettingsForm({...adminSettingsForm, newPassword: e.target.value})} className="w-full border-b border-gray-300 p-3 outline-none focus:border-black transition-colors" /></div>
                    <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Confirm New Password</label><input required type="password" value={adminSettingsForm.confirmPassword} onChange={e => setAdminSettingsForm({...adminSettingsForm, confirmPassword: e.target.value})} className="w-full border-b border-gray-300 p-3 outline-none focus:border-black transition-colors" /></div>
                  </div>
                  <div className="pt-6"><button type="submit" className="bg-black text-white px-10 py-4 font-bold uppercase tracking-[0.2em] text-xs hover:bg-[#C5A059] transition-colors">Update Credentials</button></div>
                </form>
              </div>

              <div className="bg-white shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-8 py-6 border-b border-gray-200 bg-gray-50 flex items-center"><CreditCard className="w-5 h-5 mr-4 text-black" /><h3 className="font-serif font-bold text-xl uppercase tracking-wider text-black">Payment Gateway</h3></div>
                <form onSubmit={onRazorpayUpdate} className="p-8 space-y-6">
                  <p className="text-sm text-gray-600 mb-6 font-medium leading-relaxed">Securely link your Razorpay merchant account to process wholesale distributions directly to your institutional bank account.</p>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Razorpay Key ID</label><input required type="text" placeholder="rzp_live_..." value={adminSettingsForm.rzpKeyId} onChange={e => setAdminSettingsForm({...adminSettingsForm, rzpKeyId: e.target.value})} className="w-full border border-gray-300 bg-gray-50 p-4 outline-none focus:border-black font-mono text-sm transition-colors" /></div>
                  <div><label className="block text-xs font-bold tracking-widest uppercase text-gray-500 mb-2">Razorpay Key Secret</label><input required type="password" placeholder="••••••••••••••••" value={adminSettingsForm.rzpKeySecret} onChange={e => setAdminSettingsForm({...adminSettingsForm, rzpKeySecret: e.target.value})} className="w-full border border-gray-300 bg-gray-50 p-4 outline-none focus:border-black font-mono text-sm transition-colors" /></div>
                  <div className="pt-6"><button type="submit" className="bg-black text-[#C5A059] border border-black px-10 py-4 font-bold uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-colors">Save API Keys</button></div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
