import React from 'react';
import { Copy } from 'lucide-react';

export const PrivacyPolicy = ({ content }: { content?: string }) => (
  <div className="max-w-4xl mx-auto px-4 py-16 md:py-24 animate-fade-in bg-white">
    <h1 className="text-3xl md:text-5xl font-serif text-black mb-12 text-center uppercase tracking-wider">Privacy Policy</h1>
    <div className="space-y-10 text-gray-700 font-light leading-relaxed whitespace-pre-wrap">
      {content ? content : (
        <>
          <section><h2 className="text-xl font-serif font-bold text-black mb-4 uppercase tracking-widest border-b border-gray-200 pb-2">1. Introduction</h2><p>Welcome to Akaay Enterprise. We respect the privacy of our customers and website visitors. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and purchase our wholesale products.</p></section>
          <section>
            <h2 className="text-xl font-serif font-bold text-black mb-4 uppercase tracking-widest border-b border-gray-200 pb-2">2. Information We Collect</h2>
            <p className="mb-3">We may collect information about you in a variety of ways. The information we may collect on the Site includes:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Personal & Business Data:</strong> Personally identifiable information, such as your business name, shipping address, email address, and telephone number.</li>
              <li><strong>Financial Data:</strong> Financial information securely processed by our payment gateway.</li>
            </ul>
          </section>
          <section>
            <h2 className="text-xl font-serif font-bold text-black mb-4 uppercase tracking-widest border-b border-gray-200 pb-2">3. Contact Us</h2>
            <p>Email: enterpriseakaay@gmail.com</p>
            <p className="mt-2">Phone: +91 8510066776</p>
          </section>
        </>
      )}
    </div>
  </div>
);

export const TermsOfService = ({ content }: { content?: string }) => (
  <div className="max-w-4xl mx-auto px-4 py-16 md:py-24 animate-fade-in bg-white">
    <h1 className="text-3xl md:text-5xl font-serif text-black mb-12 text-center uppercase tracking-wider">Terms of Service</h1>
    <div className="space-y-10 text-gray-700 font-light leading-relaxed whitespace-pre-wrap">
      {content ? content : (
        <>
          <section><h2 className="text-xl font-serif font-bold text-black mb-4 uppercase tracking-widest border-b border-gray-200 pb-2">1. Acceptance of Terms</h2><p>By accessing and using the Akaay Enterprise website, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by these terms, please do not use this service.</p></section>
          <section><h2 className="text-xl font-serif font-bold text-black mb-4 uppercase tracking-widest border-b border-gray-200 pb-2">2. Product Availability & Bulk Terms</h2><p>All products available for wholesale are genuine and subject to availability. Bulk orders are processed according to our distribution schedule.</p></section>
        </>
      )}
    </div>
  </div>
);

export const ContactView = ({ onNavigate, onShowToast }: { onNavigate: (v: string) => void, onShowToast: (m: string) => void }) => {
  const handleCopyEmail = () => {
    const textArea = document.createElement("textarea");
    textArea.value = "enterpriseakaay@gmail.com";
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("copy");
    document.body.removeChild(textArea);
    onShowToast("Email address copied to clipboard!");
  };
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 md:py-32 animate-fade-in bg-white text-center">
      <h1 className="text-3xl md:text-5xl font-serif text-black mb-8 uppercase tracking-wider">Contact Sales</h1>
      <div className="w-16 h-px bg-[#C5A059] mx-auto mb-10"></div>
      <p className="text-gray-600 mb-12 max-w-lg mx-auto text-lg font-light leading-relaxed">For wholesale inquiries, bulk distribution agreements, or partnership requests, please reach out to our sales team directly.</p>
      <div className="bg-gray-50 border border-gray-200 p-10 md:p-16 inline-block w-full max-w-2xl relative">
        <button onClick={handleCopyEmail} className="absolute top-4 right-4 p-2 text-gray-400 hover:text-[#C5A059] transition-colors flex items-center gap-2 group cursor-pointer" title="Copy Email"><span className="text-[10px] uppercase tracking-widest font-bold opacity-0 group-hover:opacity-100 transition-opacity">Copy</span><Copy className="w-5 h-5" /></button>
        <p className="text-[10px] font-bold tracking-widest uppercase text-gray-500 mb-4">Direct Sales Email</p>
        <a href="mailto:enterpriseakaay@gmail.com" className="text-base md:text-lg font-sans text-gray-800 hover:text-[#C5A059] transition-colors break-all lowercase tracking-wide block mb-4">enterpriseakaay@gmail.com</a>
        
        <p className="text-[10px] font-bold tracking-widest uppercase text-gray-500 mb-4 mt-8 border-t border-gray-200 pt-8">Sales Phone</p>
        <a href="tel:+918510066776" className="text-base md:text-lg font-sans text-gray-800 hover:text-[#C5A059] transition-colors tracking-wide block">+91 8510066776</a>
      </div>
      <div className="mt-16"><button onClick={() => onNavigate('HOME')} className="border border-black text-black px-10 py-4 tracking-[0.2em] text-xs uppercase font-bold hover:bg-black hover:text-white transition-colors">Return to Shop</button></div>
    </div>
  );
};
