import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, X, Trash2, Lock } from 'lucide-react';
import { Product } from '../types';

interface CartItem extends Product {
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  productsDb: Product[];
  onRemove: (id: string | number) => void;
  onUpdateQuantity: (id: string | number, delta: number) => void;
  onCheckout: () => void;
}

export default function CartDrawer({ 
  isOpen, onClose, cart, productsDb, onRemove, onUpdateQuantity, onCheckout 
}: CartDrawerProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity" 
            onClick={onClose} 
          />
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="relative w-full sm:w-[450px] bg-white h-full shadow-2xl flex flex-col border-l border-gray-200"
          >
            <div className="flex justify-between items-center p-8 border-b border-gray-100 bg-gray-50">
              <h2 className="font-serif font-bold text-xl tracking-wider uppercase text-black flex items-center gap-3">
                <ShoppingBag className="w-5 h-5"/> Your Cart
              </h2>
              <button onClick={onClose} className="text-gray-400 hover:text-red-500 transition-colors bg-white p-2 rounded-full shadow-sm border border-gray-100">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
              {cart.length === 0 ? (
                <div className="text-center text-gray-400 mt-20 flex flex-col items-center">
                  <ShoppingBag className="w-16 h-16 mb-6 opacity-30" />
                  <p className="tracking-widest uppercase text-sm font-bold mb-8">Your cart is empty</p>
                  <button onClick={onClose} className="border border-black text-black px-8 py-4 tracking-widest text-xs font-bold uppercase hover:bg-black hover:text-white transition-colors">
                    Return to Shop
                  </button>
                </div>
              ) : (
                cart.map(item => {
                  const isItemInStock = productsDb.find(p => p.id === item.id)?.inStock !== false;
                  return (
                    <div key={item.id} className={`flex gap-6 group ${!isItemInStock ? 'opacity-50' : ''} border-b border-gray-100 pb-6 last:border-0`}>
                      {item.mainMediaType === 'video' ? (
                        <video src={item.image} autoPlay muted loop playsInline className="w-24 h-32 object-cover border border-gray-200 p-1 bg-gray-50 shadow-sm" />
                      ) : (
                        <img src={item.image} alt={item.name} className="w-24 h-32 object-cover border border-gray-200 p-1 bg-gray-50 shadow-sm" />
                      )}
                      <div className="flex-1 flex flex-col justify-between py-1">
                        <div>
                          <div className="flex justify-between">
                            <h3 className="text-sm font-bold pr-4 text-black leading-tight line-clamp-2">{item.name}</h3>
                            <button onClick={() => onRemove(item.id)} className="text-gray-300 hover:text-red-500 transition-colors">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          {!isItemInStock && <p className="text-red-500 text-[10px] tracking-widest uppercase font-bold mt-2">Sold Out</p>}
                          <p className="text-gray-500 text-xs mt-2 uppercase tracking-widest">{formatPrice(item.price)}</p>
                        </div>
                        <div className="flex justify-between items-center mt-4">
                          <div className="flex items-center border border-gray-200 bg-gray-50">
                            <button onClick={() => onUpdateQuantity(item.id, -1)} className="px-3 py-1 hover:bg-gray-200 transition-colors text-gray-600">-</button>
                            <span className="text-sm px-3 font-bold bg-white border-x border-gray-200 py-1">{item.quantity}</span>
                            <button 
                              onClick={() => onUpdateQuantity(item.id, 1)} 
                              disabled={!isItemInStock} 
                              className={`px-3 py-1 transition-colors text-gray-600 ${!isItemInStock ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-200'}`}
                            >
                              +
                            </button>
                          </div>
                          <p className="text-sm font-bold text-black">{formatPrice(item.price * item.quantity)}</p>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
            
            {cart.length > 0 && (
              <div className="p-8 border-t border-gray-100 bg-gray-50">
                <div className="flex justify-between mb-6 text-sm">
                  <span className="font-bold tracking-widest uppercase text-gray-500">Subtotal</span>
                  <span className="font-bold text-black text-lg">{formatPrice(cartTotal)}</span>
                </div>
                {cart.some(item => productsDb.find(p => p.id === item.id)?.inStock === false) ? (
                  <button disabled className="w-full bg-gray-300 text-gray-500 cursor-not-allowed py-5 tracking-widest text-xs font-bold uppercase">
                    Remove Sold Items
                  </button>
                ) : (
                  <button 
                    onClick={onCheckout} 
                    className="w-full bg-black text-white py-5 font-bold tracking-widest text-xs uppercase hover:bg-[#C5A059] transition-colors flex justify-center items-center group shadow-lg"
                  >
                    Secure Checkout <Lock className="w-3 h-3 ml-3 opacity-70" />
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
