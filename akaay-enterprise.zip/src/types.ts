export interface Review {
  id: number;
  user: string;
  rating: number;
  comment: string;
  image?: string;
}

export interface MediaItem {
  id: number;
  type: 'image' | 'video';
  url: string;
}

export interface Product {
  id: string | number;
  name: string;
  price: number;
  originalPrice?: number | null;
  category: string;
  image: string;
  mainMediaType: 'image' | 'video';
  media?: MediaItem[];
  isNew?: boolean;
  inStock: boolean;
  stockQuantity: number;
  description: string;
  rating: number;
  reviews: Review[];
  saleEndDate?: string | null;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  phone?: string;
  address?: string;
  city?: string;
  pincode?: string;
  role?: 'admin' | 'user';
}

export interface Order {
  orderId: string;
  date: string;
  createdAt: string;
  customer: User;
  shipping: {
    address: string;
    city: string;
    pincode: string;
    phone: string;
    paymentMethod: string;
  };
  items: (Product & { quantity: number; reviewed?: boolean })[];
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: string;
  transactionId?: string | null;
  status: string;
  cancelReason?: string;
  returnReason?: string;
  deliveryDate?: number;
}

export const ORDER_STATUSES = [
  'Pending', 'Order Confirmed', 'Preparing', 'Product Sorting at Warehouse', 
  'Ready to Dispatch Centre', 'Received at Dispatch Centre', 'Prepared at Dispatch Centre', 
  'Ready to Ship', 'Shipped', 'Delivered', 'Cancelled', 'Return Requested', 'Returned'
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Premium Cola Cases (24x330ml)",
    price: 850, 
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=800",
    mainMediaType: 'image',
    isNew: true,
    inStock: true,
    stockQuantity: 500,
    description: "Wholesale carton of premium cola. 24 cans of 330ml each. Ideal for retail stores, restaurants, and vending machines.",
    rating: 4.8,
    reviews: [
      { id: 101, user: "Ramesh K.", rating: 5, comment: "Always fast delivery and perfect stock condition." }
    ]
  },
  {
    id: 2,
    name: "Dark Chocolate Bars Box (50 pcs)",
    price: 2500,
    category: "Chocolates",
    image: "https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&q=80&w=800",
    mainMediaType: 'image',
    inStock: true,
    stockQuantity: 300,
    description: "Bulk box containing 50 individual high-quality dark chocolate bars. Popular retail item with excellent margin.",
    rating: 4.9,
    reviews: [
      { id: 103, user: "StoreManager22", rating: 5, comment: "Best wholesale price I could find online." }
    ]
  },
  {
    id: 3,
    name: "Mixed Fruit Juice Cases (12x1L)",
    price: 1200,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80&w=800",
    mainMediaType: 'image',
    inStock: true,
    stockQuantity: 250,
    description: "100% real mixed fruit juice, no added preservatives. 12 bottles of 1 Litre each per case. Long shelf life.",
    rating: 4.7,
    reviews: []
  },
  {
    id: 4,
    name: "Assorted Candy Box (1000g)",
    price: 450,
    category: "Chocolates",
    image: "https://images.unsplash.com/photo-1582214691456-784865f3fbd5?auto=format&fit=crop&w=800&q=80",
    mainMediaType: 'image',
    inStock: true,
    stockQuantity: 150,
    description: "1KG value pack of assorted candies and wrapped chocolates. Suitable for loose retail selling or repacking.",
    rating: 4.6,
    reviews: []
  },
  {
    id: 5,
    name: "Wholesale Potato Chips (40 Packs)",
    price: 600,
    category: "Snacks",
    image: "https://images.unsplash.com/photo-1566478989037-e924e50b0a1a?auto=format&fit=crop&w=800&q=80",
    mainMediaType: 'image',
    inStock: true,
    stockQuantity: 400,
    description: "Carton of 40 individual snack-sized potato chip packs. Classic salted flavor.",
    rating: 4.8,
    reviews: []
  }
];
