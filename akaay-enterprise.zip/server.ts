import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { DatabaseSync } from "node:sqlite";
import cors from "cors";

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: "50mb" })); // Support large base64 image uploads

// Initialize SQLite database using Node.js built-in module
const db = new DatabaseSync("database.sqlite");

// Create the single generic table for documents
db.exec(`
  CREATE TABLE IF NOT EXISTS documents (
    collection TEXT NOT NULL,
    id TEXT NOT NULL,
    data TEXT NOT NULL,
    PRIMARY KEY (collection, id)
  )
`);

// GET all documents in a collection
app.get("/api/:collection", (req, res) => {
  const collection = req.params.collection;
  try {
    const defaultQuery = db.prepare("SELECT id, data FROM documents WHERE collection = ?");
    const rows = defaultQuery.all(collection) as any[];
    const result: Record<string, any> = {};
    rows.forEach(row => {
      try {
        result[row.id] = JSON.parse(row.data);
      } catch (e) {
        // ignore invalid json
      }
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET a specific document
app.get("/api/:collection/:id", (req, res) => {
  const { collection, id } = req.params;
  try {
    const query = db.prepare("SELECT data FROM documents WHERE collection = ? AND id = ?");
    const row = query.get(collection, id) as any;
    if (!row) {
      res.json(null);
      return;
    }
    try {
      res.json(JSON.parse(row.data));
    } catch (e) {
      res.json(null);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST (Create/Update) a document
app.post("/api/:collection/:id", (req, res) => {
  const { collection, id } = req.params;
  const { data, merge } = req.body; // Expecting { data: any, merge?: boolean }

  try {
    const getQuery = db.prepare("SELECT data FROM documents WHERE collection = ? AND id = ?");
    const row = getQuery.get(collection, id) as any;

    let finalData = data;
    if (merge && row) {
      try {
        const existingData = JSON.parse(row.data);
        finalData = { ...existingData, ...data };
      } catch (e) {
        console.error("Error parsing existing data for merge:", e);
      }
    }

    const dataString = JSON.stringify(finalData);
    
    if (row) {
      const updateQuery = db.prepare("UPDATE documents SET data = ? WHERE collection = ? AND id = ?");
      updateQuery.run(dataString, collection, id);
    } else {
      const insertQuery = db.prepare("INSERT INTO documents (collection, id, data) VALUES (?, ?, ?)");
      insertQuery.run(collection, id, dataString);
    }
    res.json({ success: true });
  } catch (err: any) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// DELETE a document
app.delete("/api/:collection/:id", (req, res) => {
  const { collection, id } = req.params;
  try {
    const deleteQuery = db.prepare("DELETE FROM documents WHERE collection = ? AND id = ?");
    deleteQuery.run(collection, id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log("Server running on http://localhost:3000");
  });
}

startServer();
